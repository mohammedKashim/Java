package module2;

public class Complex {
	public double rr;
	public double ii;
	// define static variables i, 1 and 0.
	static Complex ONE = new Complex (1,0);
	static Complex ZERO = new Complex (0,0);
	static Complex I = new Complex (0,1);
	
	public Complex (double x, double y) {
		rr=x; ii=y;
	}
	public Complex (){}
	
	// method returning real part of given complex number
	public double real (Complex x) {
		double rp = x.rr;
		return rp;
	}
	
	// method returning imaginary part of given complex number
	public double imag (Complex x) {
		double ip = x.ii;
		return ip;
	}
	
	// method returning modulus of given complex number
	public double modulus (Complex x) {
		double mod = Math.sqrt(x.rr*x.rr+x.ii*x.ii);
		return mod;
	}
	
	// method returning angle of given complex number
	public double angle (Complex x) {
		double a = Math.atan(x.ii/x.rr);
		return a;
	}
	
	// method returning conjugate of given complex number
	public Complex conjugate (Complex x) {
		double conj = -x.ii;
		Complex c = new Complex (rr, conj);
		return c;
	}
	
	// method returning complex number of modulus 1
	public Complex normalised (Complex x) {
		double mx = modulus(x);
		double mr = x.rr/mx;
		double mi = x.ii/mx;
		Complex n = new Complex (mr,mi);
		return n;	
	}
	
	// method returning a boolean which is "true" if and only if the current 
	// Complex number is the same as that passed in the argument. 
	public boolean equals (Complex c) {
		Complex a = new Complex (rr,ii);
		if (c.rr == a.rr && c.ii==a.ii) {
		return true;
		}
		else return false;
	}
	
	// method returning string in complex number form
	public String toString () {
		return +rr+" + "+ii+"i";
	}
	
	// method returning a complex number from magnitude and angle passed as argument
	public Complex setFromModulusAngle (double mag, double ang) {
		double rr = mag*Math.cos(ang);
		double ii = mag*Math.sin(ang);
		Complex x = new Complex (rr,ii);
		return x;
	}
	
	// method returning sum of two given complex numbers
	public static Complex add (Complex a, Complex b) {
		Complex c = new Complex (a.rr+b.rr,a.ii+b.ii);
		return c;
	}
	
	// method returning difference between two complex numbers
	public static Complex subtract (Complex a, Complex b) {
		Complex c = new Complex (a.rr-b.rr,a.ii-b.ii);
		return c;
	}
	
	// method returning multiplication between two complex numbers
	public static Complex multiply (Complex a, Complex b) {
		Complex c = new Complex (a.rr*b.rr-a.ii*b.ii,a.rr*b.ii+a.ii*b.rr);
		return c;
	}
	
	// method returning division between two complex numbers
	public static Complex divide (Complex a, Complex b) {
		Complex x = new Complex();
		Complex c = x.conjugate(b);
		double d = b.rr*c.rr-b.ii*c.ii;
		double er = (a.rr*b.rr-a.ii*b.ii)/d;
		double ei = (a.rr*b.ii+a.ii*b.rr)/d;
		Complex e = new Complex (er,ei);
		return e;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
