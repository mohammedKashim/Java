package module2;

public class TestComplex {

	public static void main(String[] args) {
		// define two complex numbers c1 = -1 + i and c2 = 1 -i
		Complex c1 = new Complex (-1,1);
		Complex c2 = new Complex (1,-1);
		// calculate the product between c1 and c2
		Complex c12 = Complex.multiply(c1,c2);
		System.out.println("c1*c2 = "+c12);
		// calculate the value of c1 divided by c2
		Complex c1divc2 = Complex.divide(c1,c2);
		System.out.println("c1/c2 = "+c1divc2);
		// calculate the product between c1 and i
		Complex c1I = Complex.multiply(c1,Complex.I);
		System.out.println("c1*I = "+c1I);
		// calculate the value of c1 divided by 0
		Complex c1divZERO = Complex.divide(c1,Complex.ZERO);
		System.out.println("c1/0 = "+c1divZERO);
		// calculate the product between c1 and the conjugate of c1
		Complex c1conjc1 = Complex.multiply(c1,c1.conjugate(c1));
		System.out.println("c1*(conj(c1)) = "+c1conjc1);
		// calculate the product between c2 and the conjugate of c2
		Complex c2conjc2 = Complex.multiply(c2,c2.conjugate(c2));
		System.out.println("c2*(conj(c2)) = "+c2conjc2);
	}

}
