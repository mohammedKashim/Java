package module2;

public class TestThreeVector {

	public static void main(String[] args) {
		// define the three vectors v1 = (3,2,1), v2 = (5,3,1) and 
		// v3 = (0,0,0) and print them to the screen
		ThreeVector v1 = new ThreeVector (3,2,1);
		ThreeVector v2 = new ThreeVector (5,3,1);
		ThreeVector v3 = new ThreeVector ();
		System.out.println("v1 = "+v1);
		System.out.println("v2 = "+v2);
		System.out.println("v3 = "+v3);
		// print to screen unit vectors in the same direction of given vectors v1, v2 and v3
		ThreeVector uv1 = v1.unitVector ();
		System.out.println("unit vector of v1 = "+uv1); 
		ThreeVector uv2 = v2.unitVector ();
		System.out.println("unit vector of v2 = "+uv2);
		ThreeVector uv3 = v3.unitVector ();
		System.out.println("unit vector of v3 = "+uv3);
		// calculate the scalar product between v1 and v2 and print to screen
		double sp12 = v1.scalarProduct(v2);
		System.out.println("v1.v2 = "+sp12);
		// calculate the scalar product between v1 and v3 and print to screen
		double sp13 = v1.scalarProduct(v3);
		System.out.println("v1.v3 = "+sp13);
		// calculate the vector product between v1 and v2 and print to screen
		ThreeVector vp12 = v1.vectorProduct(v2);
		System.out.println("v1xv2 = "+vp12);
		// calculate the vector product between v1 and v3 and print to screen
		ThreeVector vp13 = v1.vectorProduct(v3);
		System.out.println("v1xv3 = "+vp13);
		// calculate the angle between v1 and v2 and print to screen
		double a12 = v1.angle(v2);
		System.out.println("angle between v1 & v2 = "+a12);
		// calculate the angle between v1 and v3 and print to screen
		double a13 = v1.angle(v3);
		System.out.println("angle between v1 & v3 = "+a13);
	}

}
