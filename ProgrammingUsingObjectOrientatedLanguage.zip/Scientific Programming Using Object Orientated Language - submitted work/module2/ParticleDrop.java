package module2;

public class ParticleDrop {
	public double m;
	public double d;
	public double z;
	public double t;
	public double v;
	
	public ParticleDrop (double x, double y) {
		m = x; d = y;
	}
	
	// define the values of g and h
	public final double g = 9.81;
	public final double h = 6.5;
	
	// create a void method with a while loop which will iterate the distance dropped at given
	// time interval dt and loop the iterative calculation from z=h to z=0.
	public void drop(double dt) {
		double z = h; double v = 0;
		t=0; 
		while (z>=0) {
			double a = v*v*d/m-g;
			double dv = a*dt;
			double v1 = v+dv;
			double dz = v1*dt;
			double z1 = z+dz;
			z=z1;
			v=v1;
			t = t+dt;
		}
		// print to screen the total time taken for particle to drop and the final velocity of 
		// the particle
		System.out.println("t = "+t+"s"+" \n"+"final v = "+v+" m/s");
	}
	
	public static void main(String[] args) {
		// define mass m and drag coefficient d
		double m = 2.5; double d = 2;
		// print out time taken for particle to drop and final velocity for different dt
		ParticleDrop a = new ParticleDrop (m,d);
		a.drop(0.5);
		a.drop(0.1);
		a.drop(0.01);
		a.drop(0.001);
		a.drop(0.0001);
		a.drop(0.00001);
	}

}
