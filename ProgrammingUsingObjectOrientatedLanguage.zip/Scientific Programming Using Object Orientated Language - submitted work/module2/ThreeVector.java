package module2;

public class ThreeVector {
	private double xx; 
	private double yy; 
	private double zz;
	
	// define the three components of vector
	public ThreeVector(double i, double j, double k) {
		xx=i; yy=j; zz=k;
	}
	public ThreeVector() {}
	
	// create "magnitude" to calculate the magnitude of given vector
	public double magnitude() {
		double mag;
		mag = Math.sqrt(xx*xx + yy*yy + zz*zz);
		return mag;
	}
	
	// create method "unitVector" to determine unit vector in same direction as given vector
	public ThreeVector unitVector() {
		double m = magnitude(); 
		double xuv = xx/m; double yuv = yy/m; double zuv = zz/m;
		ThreeVector uv = new ThreeVector(xuv,yuv,zuv);
		return uv;
	}
	
	// create "toString" method to return as a string the components of the vector
	public String toString() {
		return "("+xx+", "+yy+", "+zz+")";
	}
	
	// static method to calculate scalar product between two given vectors
	public static double scalarProduct (ThreeVector x, ThreeVector y) {
		double sp;
		sp = x.xx*y.xx + x.yy*y.yy + x.zz*y.zz;
		return sp;
	}
	
	// static method to calculate vector product between two given vectors
	public static ThreeVector vectorProduct (ThreeVector x, ThreeVector y) {
		ThreeVector vp = new ThreeVector(x.yy*y.zz-y.yy-x.zz, y.xx*x.zz-x.xx*y.zz, x.xx*y.yy-y.yy-x.yy);
		return vp;
	}
	
	// static method to calculate sum of two given vectors
	public static ThreeVector add (ThreeVector x, ThreeVector y) {
		ThreeVector a = new ThreeVector (x.xx+y.xx,x.yy+y.yy,x.zz+y.zz);
		return a;
	}
	
	// static method to calculate angle between two given vectors
	public static double angle (ThreeVector x, ThreeVector y) {
		double dd = scalarProduct(x, y);
		double m1 = x.magnitude();
		double m2 = y.magnitude();
		double theta = Math.acos(dd/(m1*m2));
		return theta;
	}
	
	// non-static version of "scalarProduct" method
	public double scalarProduct (ThreeVector z) {
		return scalarProduct (this, z);
	}
	
	// non-static version of "vectorProduct" method
	public ThreeVector vectorProduct (ThreeVector z) {
		return vectorProduct(this, z);
	}
	
	// non-static version of "add" method
	public ThreeVector add (ThreeVector z) {
		return add(this, z);
	}
	
	// non-static version of "angle" method
	public double angle (ThreeVector z) {
		return angle(this, z);
	}
	
	
	public static void main(String[] args) {
	}

}
