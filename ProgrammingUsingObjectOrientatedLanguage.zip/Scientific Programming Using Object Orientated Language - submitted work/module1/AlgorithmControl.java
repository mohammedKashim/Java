package module1;

public class AlgorithmControl {
	public AlgorithmControl () {}
	
	// void method "loop" to print to screen numbers a to maxN in increasing steps of 1 
	public void loop(int a,int maxN) {
		for (int i =a; i <= maxN; i++){
			System.out.println("a = "+i); 
		}
	}
	
	// void method "decrement" to print to screen numbers a to x in decreasing steps of 1
	public void decrement(double a ,double x) {
		while (x >= -a) {
		System.out.println("d = "+x);	
		x--;
		}
	}
	
	// void method "increment" to print to screen numbers y to a in increasing steps of 0.5
	public void increment(double a, double y) {
		while (y <= a) {
		System.out.println("i = "+y);
		y+=0.5;
		}
	}
	
	// void method "timer" to print to screen the number of loops run so far 
	// after every l loops 
	public void timer(int l) {
		long timeNow = System.currentTimeMillis();
		int x = 0; 
		
		while (System.currentTimeMillis()<= timeNow+1000){
			x++;
			int iremainder =  x % l;
			if(iremainder == 0)
			System.out.println("no. of loops = "+x);
		}
	}

	public static void main(String[] args) {
		AlgorithmControl ag = new AlgorithmControl ();
		// calling "loop" method to print the numbers 1 to 6 to the screen
		int a=1; int maxN=6;
		ag.loop(a,maxN);
		// calling "decrement" method to print the numbers from 2 decreasing to -9 
		// to the screen
		double b = -9; double x = 2;
		ag.decrement(b, x);
		// calling "increment" method to print the numbers from 1.1 to 9.1 
		// increasing in steps of 0.5
		double c = 9.1; double y = 1.1;
		ag.increment(c, y);
		// calling "timer" method to print to the screen the number of loops run so far 
		// for every 100 and for every 10000 loops
		ag.timer(100);
		ag.timer(10000);
		// when reading for every 100 loops around 7 million loops are run after 1 second whereas for 
		// reading every 10000 loops over 25 million loops are run after 1 second. This is because
		// the system can loop more times in 1 second if it is checking after a larger number of loops
		// have been run because it is spending less processor time printing to the screen
		}

	}


