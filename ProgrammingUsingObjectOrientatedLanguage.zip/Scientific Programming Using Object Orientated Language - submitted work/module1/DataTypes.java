package module1;

public class DataTypes {

	public static void main(String[] args) {
		// assigning a double variable a1 = 100.0 and print its name and value to the screen 
		double a1 = 100.0;
		System.out.println("a1 = "+a1);
		
		// cast all literals and print results
		float a2 = 100.0f;						
		System.out.println("a2 = "+a2);
		int ia1 = (int)100.0;
		System.out.println("ia1 = "+ia1);
		long ia2 = (long)100;
		System.out.println("ia2 = "+ia2);
		byte ia3 = (byte)100.0;
		
		// print result of multiplying each value by itself
		System.out.println("ia3 = "+ia3);		
		System.out.println("a1*a1 = "+a1*a1);
		System.out.println("a2*a2 = "+a2*a2);
		System.out.println("ia1*ia1 = "+ia1*ia1);
		System.out.println("ia2*ia2 = "+ia2*ia2);
		System.out.println("ia3*ia3 = "+ia3*ia3);
		
		// find result of mixing types
		char ak = 'a'+10;					
		char dk = 'd'+7;
		System.out.println("'a' + 10 = "+ak); 	
		// both should give k (gives 10th character after 'a')
		System.out.println("'d' + 7 = "+dk);	
		// gives 7th character after 'd'
		
		// ** int j=1; int i; j=i+1; ** 
		// java does not recognise unassigned values, gives error
		
		// cast double to integer
		double d = 1.99; int id = (int)d;	
		System.out.println("int d = "+id);	
		// gives d=1, takes only integer value of floating no.
	}

}
