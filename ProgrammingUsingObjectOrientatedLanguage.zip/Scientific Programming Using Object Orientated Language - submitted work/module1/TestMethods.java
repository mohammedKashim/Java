package module1;

public class TestMethods {
	public TestMethods() {}
	
	// creating a method to calculate the dot product between two given vectors
	public double dotproduct (double x1,double y1,double z1,double x2,double y2,double z2) {
		double dp;
		dp = x1*x2 + y1*y2 + z1*z2;
		return dp;
	}
	
	// creating a method to calculate the magnitude of a given vector
	public double mag (double x, double y, double z) {
		double m;
		m = Math.sqrt(x*x + y*y + z*z);
		return m;
	}
	
	// creating a method to calculate the angle between two given vectors
	public double angle (double x1,double y1,double z1,double x2,double y2,double z2) {
		TestMethods tm = new TestMethods();
		double dd = tm.dotproduct(x1, y1, z1, x2, y2, z2);
		double m1 = tm.mag(x1,y1,z1);
		double m2 = tm.mag(x2,y2,z2);
		double theta = Math.acos(dd/(m1*m2));
		double degtheta = Math.toDegrees(theta);
		return degtheta;
	}

	public static void main(String[] args) {
		TestMethods tm = new TestMethods();
		// assigning the variables of the two vectors (5,3,2) and (2,3,1)
		double x1 = 5; double y1 = 3; double z1 = 2;
		double x2 = 2; double y2 = 3; double z2 = 1;
		// testing the "dotproduct" method by calling it
		double dd = tm.dotproduct(x1, y1, z1, x2, y2, z2);
		System.out.println("dotproduct = "+dd);
		// testing the "mag" method by calling it
		double mm = tm.mag(x1,y1,z1);
		System.out.println("magnitude = "+mm);
		// calling the "angle" method using the vectors (5,3,2) and (2,3,1)
		double aa = tm.angle(x1,y1,z1,x2,y2,z2);
		System.out.println("theta = "+aa);
		// the result given is theta = 24.4 degrees (3sf)
		
		// assigning the variables of the two vectors (1,1,2) and (0,0,0)
		double x3 = 1; double y3 = 1; double z3 = 2;
		double x4 = 0; double y4 = 0; double z4 = 0;
		// calling the "angle" method using the vectors (1,1,2) and (0,0,0)
		double ab = tm.angle(x3,y3,z3,x4,y4,z4);
		System.out.println("theta = "+ab);
		// the result is NaN as expected since the angle cannot be found between a vector and the origin

	}
}
