package module3;

public class ThreeVector {
	private double xx; 
	private double yy; 
	private double zz;
	
	public ThreeVector(double i, double j, double k) {
		xx=i; yy=j; zz=k;
	}
	public ThreeVector() {}

	public double magnitude() {
		double mag;
		mag = Math.sqrt(xx*xx + yy*yy + zz*zz);
		return mag;
	}
	
	// add exception when a vector of modulus 0 is passed as argument
	public ThreeVector unitVector() throws Exception {
		double m = magnitude(); 
		if (m == 0) {
			throw new Exception ("cannot determine unit vector of a vector of modulus 0");
		}
		double xuv = xx/m; double yuv = yy/m; double zuv = zz/m;
		ThreeVector uv = new ThreeVector(xuv,yuv,zuv);
		return uv;
	}
	
	public String toString() {
		return "("+xx+", "+yy+", "+zz+")";
	}
	
	public static double scalarProduct (ThreeVector x, ThreeVector y) {
		double sp;
		sp = x.xx*y.xx + x.yy*y.yy + x.zz*y.zz;
		return sp;
	}
	
	public static ThreeVector vectorProduct (ThreeVector x, ThreeVector y) {
		ThreeVector vp = new ThreeVector(x.yy*y.zz-y.yy-x.zz, y.xx*x.zz-x.xx*y.zz, x.xx*y.yy-y.yy-x.yy);
		return vp;
	}
	
	public static ThreeVector add (ThreeVector x, ThreeVector y) {
		ThreeVector a = new ThreeVector (x.xx+y.xx,x.yy+y.yy,x.zz+y.zz);
		return a;
	}
	
	//add exception when a vector (0,0,0) is passed as any one of the arguments
	public static double angle (ThreeVector x, ThreeVector y) throws Exception {
		double dd = scalarProduct(x, y);
		double m1 = x.magnitude();
		double m2 = y.magnitude();
		if (m1 == 0 || m2 == 0) {
			throw new Exception ("cannot determine angle between a vector and point (0,0,0)");
		}
		double theta = Math.acos(dd/(m1*m2));
		return theta;
	}
	
	public double scalarProduct (ThreeVector z) {
		return scalarProduct (this, z);
	}
	
	public ThreeVector vectorProduct (ThreeVector z) {
		return vectorProduct(this, z);
	}
	
	public ThreeVector add (ThreeVector z) {
		return add(this, z);
	}
	
	public double angle (ThreeVector z) throws Exception {
		return angle(this, z);
	}
	
	public static void main(String[] args) {
		ThreeVector a = new ThreeVector ();
		ThreeVector b = new ThreeVector (1,2,3);
		// call "unitVector" method using vector (0,0,0)
		try {
			@SuppressWarnings("unused")
			ThreeVector ua = a.unitVector();
		} catch (Exception e) {
			System.out.println("unit vector of (0,0,0) = "+e.getMessage());
		}
		// call "angle" method using vector (0,0,0) as one of the arguments
		try {
			@SuppressWarnings("unused")
			double ab = a.angle(b);
		} catch (Exception e) {
			System.out.println("angle between vector and (0,0,0) = "+e.getMessage());
		}
	}

}
