package module3;

public class TestAlphabet {

	// Loop 100 times using the methods in Alphabet on each iteration 
	// & print to screen the sum of all the digits that have been generated,
	// and the number of times Alphabet.printChar() has thrown an exception
	public static void main(String[] args) {
		Alphabet x = new Alphabet();
		double a = 0;
		int exceptionCounter = 0; int digitCounter = 0;
		while (a < 100) {
			char c = x.randomChar();
			try {
				x.printChar(c);
			} catch (Exception e1) {
				System.out.println(e1.getMessage());
				exceptionCounter++;
			}
			try {
				int y = x.charToInt(c);
				int z = digitCounter+y;
				digitCounter = z;
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			a++;
			
		}
		System.out.println("Sum of all digits generated = "+digitCounter+
				"\nNumber of characters not digits or letters = "+exceptionCounter);

	}

}
