package module3;

public class Alphabet {

	// create a method which will generate a random character the integer 
	// representation of which is in the range 0-127 
	public char randomChar () {
		int a = (int) (Math.random()*128);
		char c =  (char) a;
		return c;
	}
	
	// create a method which will print to the screen if the character given is a letter or digit 
	// otherwise throw an exception
	public void printChar (char c) throws Exception {
		if (Character.isLetterOrDigit(c)) {
			System.out.println("Your random character is = "+c);
		}
		else throw new Exception ("The random character is not a letter or digit");
	}
	
	// create a method which will attempt to convert the character into an integer value 
	// If the method throws an exception, return 0
	public int charToInt (char c) throws Exception {
		int a = Integer.parseInt(Character.toString(c));
		try {
			@SuppressWarnings("unused")
			int b = Integer.parseInt(Character.toString(c));
		} catch (Exception e){
			System.out.println(+0);
		}
		return a;
	}

}
