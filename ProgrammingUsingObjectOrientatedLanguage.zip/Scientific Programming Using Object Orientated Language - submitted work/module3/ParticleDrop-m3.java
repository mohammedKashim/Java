package module3;

public class ParticleDrop {
	public double m;
	public double d;
	public double z;
	public double t;
	public double v;
	
	// throw exception when a negative mass is passed in the argument
	public ParticleDrop (double x, double y) throws Exception {
		m = x; d = y;
		if (m < 0) {
		throw new Exception ("cannot have a negative mass!");
		}
	}
	
	public final double g = 9.81;
	public final double h = 6.5;
	
	public void drop(double dt) throws Exception {
		// throw exception for time increment, dt > 1 passed in the argument
		if (dt > 1) {
			throw new Exception ("time increment dt > 1");
		}
		z = h; v = 0;
		t=0; 
		while (z>=0) {
			double a = v*v*d/m-g;
			double dv = a*dt;
			double v1 = v+dv;
			double dz = v1*dt;
			double z1 = z+dz;
			z=z1;
			// throw exception if z > h
			if (z > h) {
				throw new Exception ("Critical Error! The particle is falling upwards.");
			}
			v=v1;
			t = t+dt;
			// throw exception if t > 20
			if (t > 20) {
				throw new Exception ("The particle has taken longer than 20 seconds to drop");
			}
		}
		System.out.println("t = "+t+"s"+" \n"+"final v = "+v+" m/s");
	}
	
	public static void main(String[] args) {
		double m = -1; double d = 2;
		ParticleDrop a;
		// call "ParticleDrop" method with a negative mass
		try {
			a = new ParticleDrop (m,d);
		} catch (Exception e) {
			System.out.println("particle with negative mass = "+e.getMessage());
		}
		// call "ParticleDrop" method with dt > 1
		try {
			a = new ParticleDrop (2,3);
			a.drop(1.5);
		} catch (Exception e) {
			System.out.println("try dt > 1 = "+e.getMessage());
		}
		
	}

}
