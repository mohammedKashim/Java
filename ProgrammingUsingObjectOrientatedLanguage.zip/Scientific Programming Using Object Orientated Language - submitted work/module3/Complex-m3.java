package module3;

public class Complex {
	public double rr;
	public double ii;
	static Complex ONE = new Complex (1,0);
	static Complex ZERO = new Complex (0,0);
	static Complex I = new Complex (0,1);
	
	public Complex (double x, double y) {
		rr=x; ii=y;
	}
	public Complex (){}
	
	public double real (Complex x) {
		double rp = x.rr;
		return rp;
	}
	
	public double imag (Complex x) {
		double ip = x.ii;
		return ip;
	}
	
	public double modulus (Complex x) {
		double mod = Math.sqrt(x.rr*x.rr+x.ii*x.ii);
		return mod;
	}
	
	public double angle (Complex x) { 
		double a = Math.atan(x.ii/x.rr);
		return a;
	}
	
	public Complex conjugate (Complex x) {
		double conj = -x.ii;
		Complex c = new Complex (rr, conj);
		return c;
	}
	
	// add exception when a complex number of modulus 0 is passed as the argument
	public Complex normalised (Complex x) throws Exception {
		double mx = modulus(x);
		if (mx == 0)  {
			throw new Exception ("cannot normalise a complex number of modulus 0");
		}
		double mr = x.rr/mx;
		double mi = x.ii/mx;
		Complex n = new Complex (mr,mi);
		return n;	
	}
	
	public boolean equals (Complex c) {
		Complex a = new Complex (rr,ii);
		if (c.rr == a.rr && c.ii==a.ii) {
		return true;
		}
		else return false;
	}
	
	public String toString () {
		return +rr+" + "+ii+"i";
	}
	
	public Complex setFromModulusAngle (double mag, double ang) {
		double rr = mag*Math.cos(ang);
		double ii = mag*Math.sin(ang);
		Complex x = new Complex (rr,ii);
		return x;
	}
	
	public static Complex add (Complex a, Complex b) {
		Complex c = new Complex (a.rr+b.rr,a.ii+b.ii);
		return c;
	}
	
	public static Complex subtract (Complex a, Complex b) {
		Complex c = new Complex (a.rr-b.rr,a.ii-b.ii);
		return c;
	}
	
	public static Complex multiply (Complex a, Complex b) {
		Complex c = new Complex (a.rr*b.rr-a.ii*b.ii,a.rr*b.ii+a.ii*b.rr);
		return c;
	}
	
	// add exception when 0 is passed as the second argument
	public static Complex divide (Complex a, Complex b) throws Exception {
		if (b.ii == 0 && b.rr == 0)  {
			throw new Exception ("cannot divide by 0, please change the second " +
					"number passed in the argument to a non-zero number");
		}
		Complex x = new Complex();
		Complex c = x.conjugate(b);
		double d = b.rr*c.rr-b.ii*c.ii;
		double er = (a.rr*b.rr-a.ii*b.ii)/d;
		double ei = (a.rr*b.ii+a.ii*b.rr)/d;
		Complex e = new Complex (er,ei);
		return e;
	}
	
	public static void main(String[] args) throws Exception {
		Complex c1 = new Complex (0,1);
		@SuppressWarnings("unused")
		Complex c = null;
		// call the "divide" method using try/catch with 0 as the second argument
		try {
			c = Complex.divide(c1,Complex.ZERO);
		} catch (Exception e) {	
			System.out.println("c1/0 = "+e.getMessage());
		}
		// call "normalised" method using try/catch with 0 as argument
		try {
			c = c1.normalised(Complex.ZERO);
		} catch (Exception e) {
			System.out.println("normalise 0+0i = "+e.getMessage());
		}
		
	}

}
