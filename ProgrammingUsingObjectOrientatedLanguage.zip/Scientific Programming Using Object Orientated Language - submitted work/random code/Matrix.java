package module5;

public class Matrix {
	
	 int r; //Initialising number of rows variable
	 int c; //Initialising number of columns variable
	 double[][] m; //Saying that m is a 2d-array
	
	public Matrix (double[][] m){  //Constructing new matrix type
		
		r = m.length; //Setting the number of rows/columns by measuring the array
		c = m[0].length;
		
		this.m = new double [r][c]; //Setting the size of m
		
		for (int i = 0; i < r; i++) {
		
				for(int j = 0; j < c; j++) {
		
					this.m[i][j] = m[i][j];
			}
		}//sets all the elements in variable this.m to the elements array m.
		
	}
	
	
	
	public int nrows(){
		System.out.println("Number of rows in the Matrix:"); 
		
		int nrows;
		nrows = m.length;
		return nrows;  //Returns the integer number of rows using m.length.
	}
	public int ncols(){
		System.out.println("Number of columns in the Matrix:");

		int ncols;
		ncols = m[0].length;
		return ncols; //Returns the integer number of columns using m[0].length.
	}
	
	public boolean isSquare(){
		  System.out.println("The Matrix is square...true or false?:");
		
		if (m.length == m[0].length){return true;}  //Will return true only if the number of columns is equal to the number of rows.
		else {return false;}
		
	}
	
	public Matrix diagonal ()throws Exception {
		
		if (r != c) throw new Exception ("Matrix not square"); //Exception if matrix isn't square
		
		double[][]a = new double [r][r]; //new array of zeroes
		
		 for (int i = 0; i < r; i++){
			 a[i][i]=m[i][i];  //Sets diagonal elements of array equal to input array
		 }
		Matrix A = new Matrix(a); //Makes new matrix object from the array
		System.out.println("Diagonal elements of the matrix");
		return A;	
		}
        
	
	
	public static Matrix add (Matrix m1, Matrix m2)throws Exception{
		
		if (m1.r != m2.r || m1.c != m2.c) {//Exception if matrices are different sizes
			throw new Exception ("Matrices not same dimensions");	
		}
		
		double[][]ar = new double [m1.r][m1.c]; //makes new array of correct size
		Matrix m3 = new Matrix (ar); //new Matrix of zeroes
		for (int i = 0; i < m1.r; i++){
            for (int j = 0; j < m1.c; j++){
                m3.m[i][j] = m1.m[i][j] + m2.m[i][j];//For all elements adds the elements of m1 and m2 sets equal to m3
            }
		}
		System.out.println("Sum of matrices");
        return m3;	
	}
	
	public Matrix add(Matrix m2)throws Exception {//non-static version of add
        
		return add(this, m2);
        }
        
	
	public static boolean equals (Matrix m1, Matrix m2) throws Exception {
		
		if (m1.r != m2.r || m1.c != m2.c) { //Exception if matrices aren't of same dimensions
			throw new Exception("Matrices not same dimensions");	
					
	}
		System.out.println("The matrices are equal...true or false?:");
		
		for (int i = 0; i < m1.r; i++){ 
            for (int j = 0; j < m1.c; j++){
                if (m1.m[i][j] == m2.m[i][j]){}//If elements are equal, keeps running.
                else {return false;} //If any aren't it returns false
            }
        }
		return true; //Returns true otherwise
	}
	
	public boolean equals (Matrix m2)throws Exception { //non static version of equals
		
		return equals(this,m2);
	}
	
	 public void viewMatrix() { //Method that displays matrices
		 
		 int i = 0;    //Row and column counters
		 			
		 System.out.println("Matrix is:");
		 
		 while (i < r) {
			 
			 StringBuilder sb = new StringBuilder (""); //New Stringbuilder object each time it reads a row
			 
			 int j = 0;
			 
			 while (j < c) {  
				 
				 String s = Double.toString(m[i][j]); //Converts the double matrix elements into strings
				 
				 sb.append(s+" "); //Two while loops that make a string from a row then print and repeat for all rows.
				 
				 j++;	 	 
			 }
			 System.out.println(sb);
			 i++;
		 }
		 
	 }
	
	public static void main(String[] args) throws Exception {
		 
		double[][] ar1 = { { 1, 2, 3 }, { 4, 5, 6 }, { 9, 1, 3}}; //New Array
	        Matrix m1 = new Matrix(ar1); //New Matrix from array
	        m1.viewMatrix ();     //Displaying matrix
	        
	        
	        System.out.println(" ");  
	        
	    double[][] ar2 = { { 8, 5, 8 }, { 7, 4, 7 }, { 6, 3, 6} };//Another array and matrix
	        Matrix m2 = new Matrix(ar2);
	        m2.viewMatrix ();     
	       
	       System.out.println("");
	         
	       int c = m1.ncols();//Running the various methods...
	       System.out.println(c);
	       
	       System.out.println("");
	       
	       int r = m1.nrows();
	       System.out.println(r);
	       
	       System.out.println(" ");
	       
	       boolean sq = m1.isSquare();
	       System.out.println(sq);
	       
	       System.out.println(" ");
	       
	       try {Matrix d = m1.diagonal();
	       		d.viewMatrix();
	       }
	       catch (Exception e){System.out.println(e);
	       }
	       
	       
	       System.out.println(" ");
	       
	       try {Matrix a = m1.add(m2);
	       a.viewMatrix();
	       }
	       catch (Exception e){System.out.println(e);}
	       System.out.println(" ");
	       
	       try {Matrix b = Matrix.add(m1, m2);
	       b.viewMatrix();
	       }
	       catch(Exception f){System.out.println(f);}
	       
	       System.out.println(" ");
	       
	       try {Boolean g = m1.equals(m2);
	       System.out.println(g);}
	       
	       catch(Exception h){System.out.println(h);}
	       
	       System.out.println(" ");
	       
	       try {Boolean f = Matrix.equals(m1, m2);
	       System.out.println(f);}
	       
	       catch(Exception j){System.out.println(j);}
	       	       	     
	}

}
//PRINT OUT
//  Matrix is:
//	1.0 2.0 3.0 
//	4.0 5.0 6.0 
//	9.0 1.0 3.0 
	 
//	Matrix is:
//	8.0 5.0 8.0 
//	7.0 4.0 7.0 
//	6.0 3.0 6.0 

//	Number of columns in the Matrix:
//	3

//	Number of rows in the Matrix:
//	3
	 
//	The Matrix is square...true or false?:
//	true
	 
//	Diagonal elements of the matrix
//	Matrix is:
//	1.0 0.0 0.0 
//	0.0 5.0 0.0 
//	0.0 0.0 3.0 
	 
//	Sum of matrices
//	Matrix is:
//	9.0 7.0 11.0 
//	11.0 9.0 13.0 
//	15.0 4.0 9.0 
	 
//	Sum of matrices
//	Matrix is:
//	9.0 7.0 11.0 
//	11.0 9.0 13.0 
//	15.0 4.0 9.0 
	 
//	The matrices are equal...true or false?:
//	false
	 
//	The matrices are equal...true or false?:
//	false


