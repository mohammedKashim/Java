package module5;

import java.util.HashMap;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.net.URL;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

public class DataAnalysis {

    private static HashMap<Double, DataPoint> map = new HashMap<Double, DataPoint>(); //new hashmap object called "map" Index number or "key" is double, and data point holds the information

    public static DataPoint getDataPoint(String line) throws IOException {
    	
    	
        DataPoint dp = new DataPoint();
        Scanner scan = new Scanner(line);
        dp.set_x(scan.nextDouble());   //This method makes a data point object that stores x,y and ey.
        dp.set_y(scan.nextDouble());    //Sets x as the first number y as the second and ey as the third and returns the data point object.
        dp.set_ey(scan.nextDouble());
        scan.close();
        return dp;
    }

    public static double getDouble(String line) throws IOException {
        double gd = 0;
        Scanner scan = new Scanner(line);
        
        while (scan.hasNextDouble() == true)
        {gd = scan.nextDouble();} 
       // gd = scan.nextDouble(); //This method finds the last index value and returns it.
       // gd = scan.nextDouble();
       // gd = scan.nextDouble();
        scan.close();
        return gd;
    }

   // public void makeHashMap(String filename) throws IOException {
    //    String line = "";
   //     FileReader fR = new FileReader(filename);
   //     BufferedReader buffR = new BufferedReader(fR);
   //     double r = 0;
   //     DataPoint dp = null;
   //     while ((line = buffR.readLine()) != null) {
   //         r = getDouble(line);
   //         dp = getDataPoint(line);
    //        map.put(r, dp);
    //    }
   // }

    public void readURL(String urlName) throws IOException {
        String line = "";  //Initializes a new string called line
        URL url = new URL(urlName);  //makes a new URL object
        InputStream iStream = url.openStream(); //
        InputStreamReader iStreamR = new InputStreamReader(iStream);
        BufferedReader buffR = new BufferedReader(iStreamR);  //Method for inputting a URL
        double r = 0;
        DataPoint ru = null;  //Initialising the index r and the data point object ru 
        while ((line = buffR.readLine()) != null) { //So the string "line" is the url line. and whilst there are url lines left
            r = getDouble(line);					//it gets the index r from the url line "line"
            ru = getDataPoint(line);				//and gets the x y an ey values and puts them in the hashmap
            map.put(r, ru);
        }
    }

    public static ArrayList<DataPoint> dataPoints() {
        ArrayList<DataPoint> array_list = new ArrayList<DataPoint>();// Defines a new array list that takes data point objects
        array_list.addAll(map.values()); //adds all the hashmap values into the arraylist
        return array_list;
    }

   // public static ArrayList<Double> extractXfromArrayList(HashMap<Double, DataPoint> map) {
    //    ArrayList<Double> array_list = new ArrayList<Double>();
    //    Iterator<DataPoint> idp = dataPoints().iterator();
      //  while (idp.hasNext()) {
     //      array_list.add(idp.next().get_x());
     //   }
     //   return array_list;
   // }

  //  public static ArrayList<Double> extractYfromArrayList(HashMap<Double, DataPoint> map) {
      //  ArrayList<Double> array_list = new ArrayList<Double>();
      //  Iterator<DataPoint> idp = dataPoints().iterator();
      //  while (idp.hasNext()) {
       //     array_list.add(idp.next().get_y());
      //  }
      //  return array_list;
    //}

    //public static ArrayList<Double> extractEYfromArrayList(HashMap<Double, DataPoint> map) {
       // ArrayList<Double> array_list = new ArrayList<Double>();
       // Iterator<DataPoint> extract = dataPoints().iterator();
     //   while (extract.hasNext()) {
      //      array_list.add(extract.next().get_ey());
     //   }
     //   return array_list;
   // }

    public static double goodnessOfFit(Theory theory, ArrayList<DataPoint> array_list) {
        double chi_squared = 0;
        for (DataPoint dp : array_list) {//Quick way to loopover a collection or array
            chi_squared += Math.pow(dp.get_y() - theory.Y(dp.get_x()), 2) / Math.pow(dp.get_ey(), 2);//calculates and adds up all the chi squaredez.
        }
        return chi_squared;  
    }

    public static void main(String[] args) {
        DataAnalysis da = new DataAnalysis();
        Theory th = new Theory(2);
        Theory th1 = new Theory(4);
        try {
            da.readURL("http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/exercise5.data ");  //uses data analysis object "da" to run data analysis method "readurl"
            System.out.println("Data no.: " + DataAnalysis.dataPoints().size());
            double goodnessOfFit1 = DataAnalysis.goodnessOfFit(th, dataPoints());
            double goodnessOfFit2 = DataAnalysis.goodnessOfFit(th1, dataPoints());
            System.out.println("Chi-squared value using y = x^2: " + goodnessOfFit1);
            System.out.println("Chi-squared value using y = x^4: " + goodnessOfFit2);
            if (goodnessOfFit1 < goodnessOfFit2) {
                System.out.println("x^2 fits better");
            } else if (goodnessOfFit2 < goodnessOfFit1) {
                System.out.println("x^4 fits better");
            } else {
                System.out.println("Equal chi-squared values");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}