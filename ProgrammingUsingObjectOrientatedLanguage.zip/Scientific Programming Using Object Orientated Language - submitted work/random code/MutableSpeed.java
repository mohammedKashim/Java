package module5;

import java.io.*;

import module3.Alphabet;
import java.util.Scanner;

public class MutableSpeed {
	
	public MutableSpeed () {}
	
	private String filename = ""; 
	
	public void writeFile (String filename) throws Exception {
	
		this.filename = filename;
	
		File charfile = new File ("R:\\wts\\mywork\\"+filename+".txt");//String takes filename and puts it in address to make file.
		FileWriter fw = new FileWriter (charfile);
		BufferedWriter bw = new BufferedWriter (fw);
		PrintWriter pw = new PrintWriter (bw); //Printwriter object that goes 
		//through buffered and filewriter and is turned into a file.
		
		
		
		int lc = 0; //line counter
		
		while (lc <10){
			
			int cc = 0;
			
			while (cc < 10){
				
			char i = Alphabet.randomChar();
			//String s = Character.toString(i);
			pw.write(i); //Writes the randomchar to line  whilst 100 chars and 10000 lines haven't been completed
			cc++;
			}
		lc++;
		}
		pw.close(); //closes the printwriter stream
	}
	
	public String readFileString ()throws Exception {
		
		BufferedReader br = null;
		try {
			 br = new BufferedReader (new FileReader("R:\\wts\\mywork\\"+filename+".txt"));
		} catch (FileNotFoundException e) {} //buffered reader object reads the created file
		
		String s = br.readLine(); //Reads a line as a string
		String fs =""; //initialises string
		while (s != null){ //Whilst there's lines left
			fs += s; //Add the string to the previous string
		}
		return fs;
				
	}
	
public StringBuilder readFileStringBuilder ()throws Exception {
		
		BufferedReader br = null;
		try {
			 br = new BufferedReader (new FileReader("R:\\wts\\mywork\\"+filename+".txt"));
		} catch (FileNotFoundException e) {}
		String s = br.readLine();
		
		StringBuilder sb = new StringBuilder (""); //New stringbuilder object
		
		while (s != null){ //As above
			sb.append(s); //Stringbuilder method that adds strings together
		}
		return sb;
		
}

	
	public static void main(String[] args) throws Exception {
		
		
		MutableSpeed m = new MutableSpeed(); //new Mutable speed object
		
		m.writeFile("MutableSpeed"); //runs write file method
		
		long timeNow1 = System.currentTimeMillis(); //Gets the time
		m.readFileString();         //runs readfile method
		long tfs = (System.currentTimeMillis()- timeNow1); //Gets the time again and calculates the difference in time before the method was run
															//So acts as a timer
		
		long timeNow2 = System.currentTimeMillis();
		m.readFileStringBuilder();
		long tfsb = System.currentTimeMillis()- timeNow2; //same again for stringbuilder
		
		long Ratio = (tfs/tfsb);
		System.out.println("Doesn't work "+Ratio); //Calculates ratio of two times.
		
		
	}

}

