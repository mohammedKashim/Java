package practice;



public class temps {
	
	public int xt;
	public String d1;
	
	public temps(String date, int i){
		xt = i;
		d1 = date;
	}

}
