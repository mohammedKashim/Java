package practice;

import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Stations {
	public Map<String, String> stat;
	
	public Stations(){
		stat = new HashMap<String, String>();
		BufferedReader br1;
		try {
			br1 = class1.brURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2010-11/final/stations.txt");
		String line2 = "";
			while ((line2 = br1.readLine()) != null) {	
				String station = "";
				Scanner sc = new Scanner(line2);
				String code = sc.next();
				while(sc.hasNext()){
					station += sc.next()+" ";
				}
				stat.put(code, station);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
