package practice;

import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Country {
	public Map<String, String> coun;
	public String name;
	
	public Country(){
		coun = new HashMap<String, String>();
		try{
			BufferedReader br2=class1.brURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2010-11/final/countries.txt");
		String line3 = "";
		while ((line3 = br2.readLine()) != null) {	
			String cName = "";
			Scanner sc = new Scanner(line3);
			String code = sc.next();
			while(sc.hasNext()){
				cName += sc.next()+" ";
			}
			coun.put(code, cName);
		}
	}
		catch(Exception e){}
	}

}
