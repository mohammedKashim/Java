package exam1;

import java.util.ArrayList;


public class Positionxyz {
	
	private double x;  //Stating the type of the variable x,y,z and aL
    private double y;
    private double z;
    private ArrayList<Double> aL; 
    
    
    public Positionxyz(){ //Constructor for positionxyz object for when no arguments are given
        ArrayList<Double> aL = new ArrayList<Double>();
        aL.add(0, 0.00);
        aL.add(1, 0.00);
        aL.add(2, 0.00);//creates an arraylist of zeroes
    	}
    

    public Positionxyz (Double x, Double y, Double z){ //Constructor for object type that stores three doubles x,y and z
    	this.x = x;
    	this.y = y;
    	this.z = z;
    	 ArrayList<Double> aL = new ArrayList<Double>();//And creates an arraylist object that holds x,y and z
         aL.add(0, x);
         aL.add(1, y);
         aL.add(2, z);
    }

    public double get_x(){ //Method for retrieving the x position value
        return x;
    }
    
    public void set_x(Double xSet) { //Method for setting the x position value
        this.x = xSet;
      }
    
    public double get_y(){
        return y;
    }
    
    public void set_y(Double ySet) {//Same as above for y position
        this.y = ySet;
      }
    public double get_z(){
        return z;
    }
    
    public void set_z(Double zSet) {//Same as above for z position
        this.z = zSet;
      }
    
    public Object[] get_xyzArray(){ //Method for retrieving the postionxyz array 
        return aL.toArray();
    }

}
	
