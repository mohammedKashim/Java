package practice;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class class1 implements stuff{
	public ArrayList<Integer> temp;
	public ArrayList<temps> total;
	public Map<String, ArrayList<temps>> m;
	public int max;
	int tmax;
	int rms;
	String location1;
	int mean;
	public Map<String, String> stat;
	public Map<String, String> coun;
	String location;
	Stations st = new Stations();
	Country ct = new Country();
	
	public static BufferedReader brURL(String urlName) throws Exception{
		URL uRL = new URL(urlName);
		InputStream is = uRL.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		return br;
	}
	
	public class1(){
		m = new HashMap<String, ArrayList<temps>>();
	}
	
	public void tMax(String s) throws Exception{ 
		temp = new ArrayList<Integer>();
		total = new ArrayList<temps>();
		if(s.contains("TMAX")){
			Scanner s1 = new Scanner(s);
			String location = s1.next();
			String dp1 = Double.toString(s1.nextDouble());
			String dp2 = Double.toString(s1.nextDouble());
			String date = dp1+" "+dp2;
			s1.next();
			while(s1.hasNext()){
				double xx = s1.nextDouble();
				temps tp = new temps(date, (int) xx);
				total = m.get(location);
				if (total == null)
					m.put(location, total=new ArrayList<temps>());
				total.add(tp);
        }	
		}
		}

	public void findtMax(){
		int tmax = -10000;
		for(String keys: m.keySet()){//this finds the tmax value for the whole data set
			ArrayList<temps> data = m.get(keys);
			int i = 0;
			int arraysize = data.size();
			while(i < arraysize){
				if(data.get(i).xt > tmax){
					tmax = data.get(i).xt;		
				}
				i++;
		}	
	}
		
		for(String keys: m.keySet()){//this is for locating the dates and locations where tmax occur
			ArrayList<temps> data = m.get(keys);
			int j = 0;
			int arraysize = data.size();
			while(j < arraysize){
				if(data.get(j).xt == 400){
					System.out.println("Country: "+ct.coun.get(keys.substring(0, 2))+" Station Name: "+st.stat.get(keys)+" Date of reading: "+ data.get(j).d1);
						}
					j++;
				}
			}
	}
	
	public void findlow(){//calculates the low average for each location
		for(String keys: m.keySet()){
			int meant = 0;
			int i = 0;
			int high = 10000;
			ArrayList<temps> data = m.get(keys);
			int arraysize = data.size();
			while(i<arraysize){
					if(data.get(i).xt!=-9999){
							meant+=data.get(i).xt;	
		}
					i++;	
	}
			mean =meant/data.size();
			if(mean<high){
				high = mean;
				location = keys;
			}
	}
		System.out.println("Country: "+ct.coun.get(location.substring(0, 2))+" Station Name: "+st.stat.get(location)+" Mean Temperature: "+mean);
	}
	
	public void RMS() {
		for(String keys: m.keySet()){
			ArrayList<temps> data = m.get(keys);
			int arraysize = data.size();
			int i = 0;
			int j =0;
			double sm = 0;
			double maxi = 0;
			while(i < arraysize){
				if(data.get(i).d1.contains("1966")){
					if(data.get(i).xt==-9999){
						j++;
					}
					else{
						sm += Math.pow(data.get(i).xt,2);
					}
				i++;
			}
			}
			rms = (int) Math.sqrt(sm/(data.size()-j));
			if(rms>maxi){
				maxi = rms;
				location1 = keys;
			}
	}
		System.out.println("Country: "+ct.coun.get(location1.substring(0, 2))+" Station Name: "+st.stat.get(location1)+" RMS: "+mean);
	}


	public static void main(String[] args){
		
		class1 c1 = new class1();
		//these are all the objects that i have created to use in the code
		try{
			BufferedReader br =brURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2010-11/final/readings.txt");
			String line = "";
			while ((line = br.readLine()) != null) {	
			c1.tMax(line);//fills the hashmap with the values from the txt file and stores them under the country codes as keys
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		c1.findtMax();
		c1.findlow();
		//c1.RMS();
		
			}

	
	public double mean() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	public double median() {
		// TODO Auto-generated method stub
		return 0;
	}


	
	
	public double Max() {
		// TODO Auto-generated method stub
		return 0;
	}
	}
	





