package practice;

public interface stuff {
	double mean();
	double median();
	void RMS();
double Max();

}
