package module5;

import java.util.ArrayList;

public class DataPoint {

    private double x;
    private double y;
    private double ey;
    private ArrayList<Double> aL;

    public DataPoint(){
        ArrayList<Double> aL = new ArrayList<Double>(); //Constructor for data point when NOTHING is inputted into it. Equivalent to ThreeVector(){}
        aL.add(0, 0.00);  			//Makes an array list of zeroes.
        aL.add(1, 0.00);
        aL.add(2, 0.00);
    }
    
    DataPoint(double x, double y, double ey){//Takes 3 double arguments and puts them into array list aL
        this.x = x;
        this.y = y;
        this.ey = ey;
        ArrayList<Double> aL = new ArrayList<Double>();
        aL.add(0, x);
        aL.add(1, y);
        aL.add(2, ey);
    }
    
   
    
    public double get_x(){
        return x;
    }
    
    public void set_x(Double xSet) {
        this.x = xSet;
      }
    
    public double get_y(){
        return y;
    }
    
    public void set_y(Double ySet) {
        this.y = ySet;
      }
    
        public double get_ey(){
        return ey;
    }
    
    public void set_ey(Double eySet) {
        this.ey = eySet;
      }
    
    public Object[] get_dpArray(){
        return aL.toArray();
    }
    
    public void printx(){
        System.out.println(this.get_x());
    }

    public void printy(){
        System.out.println(this.get_y());
    }
    
    public void printey(){
        System.out.println(this.get_ey());
    }
    
    public void printdpArray(){
        System.out.println("[ "+this.get_x()+"  "+this.get_y()+"  "+this.get_ey()+" ]");
    }
}