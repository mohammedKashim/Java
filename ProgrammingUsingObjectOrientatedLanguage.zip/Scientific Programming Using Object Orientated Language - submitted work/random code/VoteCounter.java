package module8;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.*;
import javax.swing.*;

/** A single graphical program that counts votes.
 * Left mouse click is a yes and a right mouse click
 * is a no. The two rectangles represent the percentages
 * of yes and no votes.
 * @author Valentinos Christodoulou
 * @version 1.0 (30/11/2011)
 */
@SuppressWarnings("serial")
public class VoteCounter extends JFrame {
	/** 
	 * Number of left mouse clicks.
	 */
	static int numberOfLeftClicks = 0;

	/** 
	 * Number of right mouse clicks.
	 */
	static int numberOfRightClicks = 0;

	/** 
	 * Number of total mouse clicks.
	 */
	static int totalClicks = 0;

	/** 
	 * Percentage of yes votes.
	 */
	static double yesPercentage = 0;

	/** 
	 * Percentage of no votes.
	 */
	static double noPercentage = 0;

	public VoteCounter() {
		super();

		MouseListener ml = new MouseListener() {

			/** 
			 * Increase the number of left clicks by 1 every time the
			 * left mouse button is clicked.
			 * Increase the number of right clicks by 1 every time the
			 * right mouse button is clicked.
			 * Also calculates the total number of clicks and the 
			 * percentages of yes and no votes.
			 * Repaints the GUI every time the mouse is clicked.
			 * */
			public void mouseClicked(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e)== true ) { 
					numberOfLeftClicks++;
				}
				if (SwingUtilities.isRightMouseButton(e)== true ) { 
					numberOfRightClicks++;
				}
				totalClicks = numberOfLeftClicks + numberOfRightClicks;
				if (totalClicks != 0 ) {
					yesPercentage = (double)Math.round(100*10*((double) numberOfLeftClicks)/totalClicks)/10;
					noPercentage = (double)Math.round(100*10*((double) numberOfRightClicks)/totalClicks)/10;
				}
				repaint();
			}

			/** 
			 * All the methods of the MouseListener interface must
			 * be implemented even if they don�t do anything.
			 * */
			public void mouseEntered(MouseEvent e) {
			}

			public void mouseExited(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
			}

			public void mouseReleased(MouseEvent e) {
			}
		};
		addMouseListener(ml);
	}

	/** 
	 * Create the two rectangles representing the number of 
	 * yes and no votes.
	 * Add the total number of votes at the top of the GUI and the 
	 * percentages of yes and no votes on top of each rectangle.
	 * */
	public void paint(Graphics g) {
		super.paint(g);
		if (totalClicks > 0) {
			double yesHeight = -300*numberOfLeftClicks/totalClicks;
			double noHeight = -300*numberOfRightClicks/totalClicks;
			g.setColor(Color.GREEN);
			fillRect(g,100, 500, 100, (int) yesHeight);
			g.setColor(Color.BLUE);
			fillRect(g,300, 500, 100, (int) noHeight);
			g.setColor(Color.RED);
			Font title = new Font("TimesRoman",Font.BOLD,28);
			g.setFont(title);
			g.drawString("Number of votes = "+totalClicks,100,100);
			g.setColor(Color.BLACK);
			Font f = new Font("TimesRoman",Font.BOLD,22);
			g.setFont(f);
			g.drawString("YES:"+yesPercentage+"%",100,(int) (495+yesHeight));
			g.drawString("NO:"+noPercentage+"%",300,(int) (495+noHeight));
		}
	}

	/** 
	 * New method for fillRect. Older versions of java cannot handle
	 * negative numbers in fillRect. This method allows negative
	 * numbers to be used in all versions of java.
	 * @param g graphics object
	 * @param x	x-coordinate of rectangle
	 * @param y	y-coordinate of rectangle
	 * @param width	width of the rectangle
	 * @param height height of the rectangle
	 */
	public void fillRect(Graphics g, int x, int y, int width, int height) {     
		if(width < 0)         
			x-=Math.abs(width);     
		if(height < 0)         
			y-=Math.abs(height);    
		g.fillRect(x,y,Math.abs(width), Math.abs(height));   
	}

	/** 
	 * Create and display the GUI.
	 * If the window is closed the application will exit.
	 */
	public static void main(String args[]) {
		JFrame frame = new VoteCounter();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setVisible(true);
	}
}
