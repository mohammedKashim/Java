package module5;

public class Theory {
	
	double n;
	
	public Theory (){};
	public Theory (double p){n = p;} //Constructor for theory type object. Takes a double that is used as the power of x in Y method.

	public double Y (double x){
		
		double y;
		y = Math.pow(x, n);
		return y;
	 	
		
	}
	
	public static void main(String[] args) {
		

	}

}
