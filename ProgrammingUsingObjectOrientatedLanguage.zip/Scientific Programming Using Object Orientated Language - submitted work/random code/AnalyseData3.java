package exam1;

import java.util.HashMap;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileReader;   //Importing java packages
import java.io.BufferedReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import module5.DataPoint;

public class AnalyseData3 {

	public static Positionxyz getxyz (String line){

		Positionxyz xyz = new Positionxyz(); //This method takes a string argument, that will be from the url. and returns a positionxyz object.
		Scanner scan = new Scanner(line);//Creates a new scanner object that has methods to return numbers from a string
		xyz.set_x(scan.nextDouble());   //Uses the scanner method next double to obtain the x position and sets this in the xyz object.
		xyz.set_y(scan.nextDouble());  //This does the same for y and z
		xyz.set_z(scan.nextDouble());
		scan.close();
		return xyz;

	}



	public static ArrayList<Positionxyz> readURL(String urlName) throws IOException {

		ArrayList<Positionxyz> aldata = new ArrayList<Positionxyz>();
		String line = "";   //Initialises a new string called line
		URL url = new URL(urlName);  //makes a new URL object
		InputStream iStream = url.openStream(); //
		InputStreamReader iStreamR = new InputStreamReader(iStream);
		BufferedReader buffR = new BufferedReader(iStreamR);  //Standard methods for reading a URL

		Positionxyz data = null;  //Initialising Position xyz object called 'data'

		line = buffR.readLine(); //Gets the first line and does nothing with it
		while ((line = buffR.readLine()) != null) { //For all other lines

			data = getxyz(line);				
			aldata.add(data); //This is makes an array list of  ALL the Positionxyz objects                                       	
		}
		return aldata; //One large arraylist of all the Positionxyz objects
	}




	public static HashMap hashbpm(ArrayList <Positionxyz> aldata){ //Method to make a hashmap of the whole URL arraylist.

		HashMap<Double, ArrayList <Positionxyz>> bpmdata = new HashMap<Double, ArrayList <Positionxyz>>(); //Hashmap called bpmdata that has doubles as the keys and arraylists of positionxyz objects as the values

		for (Positionxyz point : aldata ){ //For each 'line' or arraylist element
			if (bpmdata.containsKey(point.get_z())) {  //If the hashmap contains the z key already
				(bpmdata.get(point.get_z())).add(point);}  //Gets the arraylist, then uses the arraylist add function to add the new datapoint

			else {
				ArrayList <Positionxyz> temp = new ArrayList <Positionxyz>(); //If no key exists, make a new arraylist that takes Positionxyz objects
				temp.add(point); //add the position xyz object point to this arraylist
				bpmdata.put(point.get_z(), temp);  //and put this arraylist with its key(z) in the hashmap.
			}			

		}
		return bpmdata;
	}

	public static void bpmanalysis (HashMap <Double, ArrayList <Positionxyz>> hashbpm){ //Takes the hashmap and returns its keys as an arraylist.

		int numberbpm = hashbpm.size(); //Gets the number of detectors(keys)
		System.out.println("Number Of Detectors: "+numberbpm); 

		Set<Double> zPositionsTmp = hashbpm.keySet();
		TreeSet<Double> zPositions = new TreeSet<Double>();
		zPositions.addAll(zPositionsTmp);
		for (Double zPosition : zPositions) {
			double z = zPosition;
			ArrayList<Positionxyz> hits = hashbpm.get(zPosition);
			int nHits = hits.size();
			System.out.println("Number of measurements by bpm " +z+" = " + nHits);
			double ytot = 0;
			double xtot = 0;
			for (Positionxyz hit : hits) {
				xtot += hit.get_x();
				ytot += hit.get_y();
			}
			double xbar = xtot/nHits;
			double ybar = ytot/nHits;
			System.out.println("Mean position of particle at detector " +z+" x = " +xbar+ " y = "+ybar); //Prints these values
			for (Positionxyz hit : hits) {
				double deltaX = hit.get_x() - xbar;
			}
		}
	}


	public static void main(String[] args) {


		ArrayList<Positionxyz> aldata = new ArrayList<Positionxyz>();

		try {
			aldata = readURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/bpm.txt");
		} catch (IOException e) {

			e.printStackTrace();
		}

		HashMap<Double, ArrayList <Positionxyz>> bpmdata = new HashMap<Double, ArrayList <Positionxyz>>();

		AnalyseData2 ad = new AnalyseData2(); //If hashbpm wasn't static, this shit would have to go down.
		//bpmdata = ad.hashbpm(aldata);

		bpmdata = hashbpm(aldata);
		//System.out.println(bpmdata.toString());  //Prints hashmap to console



		bpmanalysis(bpmdata);










		//s = -0.0; int i = 0; double xbar = 0; double ybar = 0;		

		//while (s <=1000 && i <= 11){ //i is the reference to the arraylist made in the previous method to get the number of counts at each detector.

		//double ytot = 0;
		//double xtot = 0;


		//bpm_z.addAll(bpmdata.get(s)); //This makes bpm_z the arraylist at key 's1'
		//ArrayList <Double> xbars = new ArrayList <Double>();
		//ArrayList <Double> ybars = new ArrayList <Double>();
		//	for (Positionxyz e : bpm_z){ //For each element in each bpm arraylist

		//		double x = e.get_x();
		//		xtot += x;				 												

		//		double y = e.get_y();  //Gets the y position
		//		ytot += y; //this will add up all the y positions in the arraylist				 															
		//	}


		////////////////////////////////////////////////

		//	ybar = ytot/(bpmcounts.get(i)); //Gets the mean y position
		//	ybars.add(ybar); //adds this to the arraylist that will store all the mean y coordinates

		//	xbar = xtot/(bpmcounts.get(i)); //same for x
		//	xbars.add(xbar);

		//	System.out.println("Mean position of particle at detector " +s+" x = " +xbar+ " y = "+ybar); //Prints these values

		//	bpm_z.clear(); s += 100; i++; //clears bpm_z for the next bpm arraylist in the hashmap and changes the variables to refer to the new bpm.		

	}









}
