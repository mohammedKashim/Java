package finalexam;

import java.util.ArrayList;

public class OccABPoints {

	int occA; int occB;
	
	// creating method which will store the A,B occurrences into an ArrayList
	public OccABPoints(Integer occ1, Integer occ2) {
		occA = occ1; occB = occ2;
		ArrayList<Integer> aL = new ArrayList<Integer>();
		aL.add(0, occA);
		aL.add(1, occB);
	}
	
	// creating methods which will retrieve the A,B occurrences
	public int get_occA(){return occA;}

	public void set_occA(int occASet) {this.occA = occASet;}

	public int get_occB(){return occB;}

	public void set_y(int occBSet) {this.occB = occBSet;}

}
