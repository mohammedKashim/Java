package finalexam;

import java.util.ArrayList;

public class PPoints {

	int p;

	public PPoints(){
		ArrayList<Integer> aL = new ArrayList<Integer>(); 
		aL.add(0, 0);
	}
	
	// putting the stored population values into an Arraylist
	public PPoints(int p1) {
		p = p1;
		ArrayList<Integer> aL = new ArrayList<Integer>();
		aL.add(0, p);
	}

	// method to retrieve the population value
	public int get_p() {return p;}
	
	public void set_p(int pSet) {this.p = pSet;}

}
