package finalexam;

import java.util.ArrayList;

// this class implements the Statistics interface (will have stat method)
public class StatSig 
	implements Statistics{

	// this method (from Statistics interface)will determine the statistical significance
	// of the region with the highest statistical excess of occurrences
	public void stat() {
		DataAnalysis a = new DataAnalysis();
		int totpop = a.totPop(DataAnalysis.pPoints());
		double pi = 0;
		ArrayList<PPoints> al = new ArrayList<PPoints>();
		for (PPoints pp : al) {
			int pop = 0;
				if (pp.get_p()>pop){
					pop = pp.get_p();
				}
			System.out.println("pop = "+pop);
			pi = totpop/pop;
		}
		ArrayList<OccXYZPoints> al2 = new ArrayList<OccXYZPoints>();
		for (OccXYZPoints XYZ : al2) {
			double Sx = (XYZ.get_occX()-pi)/Math.sqrt(pi);
			double Sy = (XYZ.get_occY()-pi)/Math.sqrt(pi);
			double Sz = (XYZ.get_occZ()-pi)/Math.sqrt(pi);
			System.out.println("Stat sig of X = "+Sx);
			System.out.println("Stat sig of Y = "+Sy);
			System.out.println("Stat sig of Z = "+Sz);
		}
		ArrayList<OccABPoints> al1 = new ArrayList<OccABPoints>();
		for (OccABPoints AB : al1) {
			double Sa = (AB.get_occA()-pi)/Math.sqrt(pi);
			double Sb = (AB.get_occB()-pi)/Math.sqrt(pi);
			System.out.println("Stat sig of A = "+Sa);
			System.out.println("Stat sig of B = "+Sb);
		}
	}
		
}


