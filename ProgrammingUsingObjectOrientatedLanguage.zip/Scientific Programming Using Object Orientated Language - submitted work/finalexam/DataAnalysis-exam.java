package finalexam;

import finalexam.StoreData;
import java.io.BufferedReader;
import java.util.ArrayList;

public class DataAnalysis {

	// these methods will store all the HashMap data into an ArrayList
	public static ArrayList<OccXYZPoints> xyzPoints(){
		StoreData s = new StoreData();
		ArrayList<OccXYZPoints> al = new ArrayList<OccXYZPoints>();
		al.addAll(s.XYZmap.values());
		return al;
	}
	
	public static ArrayList<OccABPoints> abPoints(){
		StoreData s = new StoreData();
		ArrayList<OccABPoints> al = new ArrayList<OccABPoints>();
		al.addAll(s.ABmap.values());
		return al;
	}
	
	public static ArrayList<RPoints> rPoints(){
		StoreData s = new StoreData();
		ArrayList<RPoints> al = new ArrayList<RPoints>();
		al.addAll(s.Rmap.values());
		return al;
	}
	
	public static ArrayList<PPoints> pPoints(){
		StoreData s = new StoreData();
		ArrayList<PPoints> al = new ArrayList<PPoints>();
		al.addAll(s.Pmap.values());
		return al;
	}
	
	// this methods will calculate the total population 
	public int totPop(ArrayList<PPoints> al) {
		int totpop = 0;
		for (PPoints pp : al) {
			int t = pp.get_p();
			totpop = totpop + t;
		}
		System.out.println("total population of UK = "+totpop);
		return totpop;
	}
	
	// this methods will calculate the total X occurrences
	public int totoccX(ArrayList<OccXYZPoints> al) {
		int totX = 0;
		for (OccXYZPoints XYZ : al) {
			int X = XYZ.get_occX();
			totX = totX + X;
		}
		System.out.println("total occ of X = "+totX);
		return totX;
	}
	
	// this methods will calculate the total Y occurrences
	public int totoccY(ArrayList<OccXYZPoints> al) {
		int totY = 0;
		for (OccXYZPoints XYZ : al) {
			int Y = XYZ.get_occY();
			totY = totY + Y;
		}
		System.out.println("total occ of Y = "+totY);
		return totY;
	}
	
	// this methods will calculate the total Z occurrences
	public int totoccZ(ArrayList<OccXYZPoints> al) {
		int totZ = 0;
		for (OccXYZPoints XYZ : al) {
			int Z = XYZ.get_occZ();
			totZ = totZ + Z;
		}
		System.out.println("total occ of Z = "+totZ);
		return totZ;
	}
	
	// this methods will calculate the total A occurrences
	public int totoccA(ArrayList<OccABPoints> al) {
		int totA = 0;
		for (OccABPoints AB : al) {
			int A = AB.get_occA();
			totA = totA + A;
		}
		System.out.println("total occ of A = "+totA);
		return totA;
	}
	
	// this methods will calculate the total B occurrences
	public int totoccB(ArrayList<OccABPoints> al) {
		int totB = 0;
		for (OccABPoints AB : al) {
			int B = AB.get_occB();
			totB = totB + B;
		}
		System.out.println("total occ of A = "+totB);
		return totB;
	}

	public static void main(String[] args) {
		// initiating the methods to read the data files and start analysis
		StoreData s = new StoreData();
		DataAnalysis a = new DataAnalysis();
		BufferedReader b = null;
		try {
			b = s.readURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2011-12/populations.txt");
		} catch (Exception e) {}
		try {
			s.storePop(b);
		} catch (Exception e) {}
		BufferedReader b1 = null;
		try {
			b1 = s.readURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2011-12/occurrencesXYZ.txt");
		} catch (Exception e) {}
		// determine the total population
		double P1 = a.totPop(DataAnalysis.pPoints());
		try {
			s.storeOccXYZ(b1);
		} catch (Exception e) {}
		// determine the total occurrence of X, Y and Z
		double X1 = a.totoccX(DataAnalysis.xyzPoints());
		double Y1 = a.totoccY(DataAnalysis.xyzPoints());
		double Z1 = a.totoccZ(DataAnalysis.xyzPoints());
		// determine the occurrences per capita of X, Y and Z
		double tpX = X1/P1;
		double tpY = Y1/P1;
		double tpZ = Z1/P1;
		System.out.println("total occ per capita of X = "+tpX);
		System.out.println("total occ per capita of Y = "+tpY);
		System.out.println("total occ per capita of Z = "+tpZ);
		BufferedReader b2 = null;
		try {
			b2 = s.readURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2011-12/occurrencesAB.txt");
		} catch (Exception e) {}
		try {
			s.storeOccAB(b2);
		} catch (Exception e) {}
		// determine the total occurrence of A and B
		double A1 = a.totoccA(DataAnalysis.abPoints());
		double B1 = a.totoccA(DataAnalysis.abPoints());
		// determine the occurrences per capita of A and B
		double tpA = A1/P1;
		double tpB = B1/P1;
		System.out.println("total occ per capita of A = "+tpA);
		System.out.println("total occ per capita of B = "+tpB);
	}
}

