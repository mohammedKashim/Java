package finalexam;

public interface Statistics {
	
	// this interface will have the stat method which will begin statistical analysis on some data
	void stat ();

}
