package finalexam;

import java.util.ArrayList;

public class StatCorrelation 
	implements Statistics{

	// creating method which will calculate the correlation of occurrences between the diseases
	public void stat() {
		ArrayList<OccXYZPoints> al = new ArrayList<OccXYZPoints>();
		int n=0;
		int x=0; int y = 0; int z = 0;
		for (OccXYZPoints XYZ : al) {
			x = x+XYZ.get_occX();
			y = y+XYZ.get_occY();
			z = z+XYZ.get_occZ();
			n = n++;
		}
		// calculating mean values of X, Y, Z
		int meanX = x/n;
		int meanY = y/n;
		int meanZ = z/n;
		// calculate standard deviation
		double stdevX = meanX/Math.sqrt(n);
		double stdevY = meanY/Math.sqrt(n);
		double stdevZ = meanZ/Math.sqrt(n);
		// calculate correlation between X and Y
		for (OccXYZPoints XYZ : al) {
			double thiXY = (XYZ.get_occX()-meanX)*(XYZ.get_occY()-meanY)/(n*stdevX*stdevY);
			System.out.println("correlation between X and Y = "+thiXY);
		
		}
		
		
	}

}
