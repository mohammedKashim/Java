package finalexam;

import java.util.ArrayList;

public class OccXYZPoints {

	int occX; int occY; int occZ;
	
	// method to store the XYZ occurrences data into an Arraylist
	public OccXYZPoints(Integer occ1, Integer occ2, Integer occ3) {
		occX = occ1; occY = occ2; occZ = occ3;
		ArrayList<Integer> aL = new ArrayList<Integer>();
		aL.add(0, occX);
		aL.add(1, occY);
		aL.add(2, occZ);
	}
	
	// creating methods which will retrieve the X,Y,Z data 
	public int get_occX(){return occX;}

	public void set_occX(int occXSet) {this.occX = occXSet;}

	public int get_occY(){return occY;}

	public void set_occY(int occYSet) {this.occX = occYSet;}
	
	public int get_occZ(){return occZ;}

	public void set_occZ(int occZSet) {this.occZ = occZSet;}

}
