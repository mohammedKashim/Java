package finalexam;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Scanner;

public class StoreData {
	
	public HashMap<String, RPoints> Rmap = new HashMap<String, RPoints>();
	public HashMap<String, PPoints> Pmap = new HashMap<String, PPoints> ();
	public HashMap<String, OccXYZPoints> XYZmap = new HashMap<String, OccXYZPoints>();
	public HashMap<String, OccABPoints> ABmap = new HashMap<String, OccABPoints>();
	
	// creating method which will read a URL file
	public BufferedReader readURL(String url) throws Exception {
		URL u = new URL(url);
		InputStream is = u.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		return b;
	}
	
	// creating a method which will store the Regions data into a Hashmap
	public void storeRegions(BufferedReader b) throws Exception {
		String s = b.readLine();
		while (s != null) {
			Scanner t = new Scanner (s);
			t.useDelimiter(",");
			String code = t.next();
			String region  = t.next();
			Rmap.put(code, new RPoints(region));
			s = b.readLine();
		}	
	}
	
	// creating a method which will store the Populations data into a Hashmap
	public void storePop(BufferedReader b) throws Exception {
		@SuppressWarnings("unused")
		String s = b.readLine();
		int n = 0;
		String st = b.readLine();
		while (b.readLine() != null) {
			Scanner t = new Scanner (st);
			String code = t.next();
			Integer pop  = t.nextInt();
			Pmap.put(code, new PPoints(pop));
			st = b.readLine();
			n++;
		}	
		System.out.println("pop data = "+n);
		System.out.println("keyset pop = "+Pmap.keySet());
		System.out.println("entryset pop = "+Pmap.entrySet());
	}

	// creating a method which will store the OccurrencesXYZ data into a Hashmap
	public void storeOccXYZ(BufferedReader b) throws Exception {
		String s = b.readLine();
		while (s != null) {
			Scanner t = new Scanner (s);
			String code = t.next();
			Integer occX  = t.nextInt();
			Integer occY = t.nextInt();
			Integer occZ = t.nextInt();
			XYZmap.put(code, new OccXYZPoints(occX, occY, occZ));
			s = b.readLine();
		}	
	}
	
	// creating a method which will store the OccurrencesAB data into a Hashmap
	public void storeOccAB(BufferedReader b) throws Exception {
		String s = b.readLine();
		while (s != null) {
			Scanner t = new Scanner (s);
			String code = t.next();
			Integer occA  = t.nextInt();
			Integer occB = t.nextInt();
			ABmap.put(code, new OccABPoints(occA, occB));
			s = b.readLine();
		}	
	}
	
	public static void main(String[] args) throws Exception {
		// checking to see if the total population is calculated
		StoreData s = new StoreData();
		DataAnalysis a = new DataAnalysis();
		BufferedReader b = s.readURL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/2011-12/populations.txt");
		s.storePop(b);
		a.totPop(DataAnalysis.pPoints());
	}

}
