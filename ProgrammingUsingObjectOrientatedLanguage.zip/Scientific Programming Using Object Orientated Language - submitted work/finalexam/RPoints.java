package finalexam;

import java.util.ArrayList;

public class RPoints {
	
	String r;
	
	// method to store the regions data into an arraylist
	public RPoints(String r1) {
		r = r1;
		ArrayList<String> aL = new ArrayList<String>();
		aL.add(0, r1);
	}

}
