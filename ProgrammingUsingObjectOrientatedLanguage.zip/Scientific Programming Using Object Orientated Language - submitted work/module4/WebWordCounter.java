package module4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;


public class WebWordCounter {
	// creating method which will prompt user for a string and return the string to the screen
	public static String getStringFromKeyboard() {
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader b = new BufferedReader(r);
		System.out.println("Please enter a URL: ");
		String s = null;
		try {
			s = b.readLine();
			System.out.println("You wrote: "+s);
		} catch (IOException e) {
			System.out.println("Unfortunately there was a problem: "+e.getMessage());
		}
		return s;
	}
	
	// creating method read the given URL and return the no. of words in the file
	public static int countWordsInURL(String urlName) throws Exception {
		URL u = new URL(urlName);
		InputStream is = u.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		Scanner s = new Scanner(b);
		int num = 0;
		while (s.hasNext()) {
		@SuppressWarnings("unused")
		String token = s.next();
		try {
		num++;
		} catch (NumberFormatException e) {}
		}
		return num;
	}

	public static void main(String[] args) {
		// calling "getStringFromKeyboard" method
		WebWordCounter.getStringFromKeyboard();
		// calling "countWordsInURL" method
		try {
			int c = WebWordCounter.countWordsInURL("http://www.hep.ucl.ac.uk/~waugh/phas3459/testfile.txt");
			System.out.println("Number of words found in URL file = "+c);
		} catch (Exception e) {}

	}

}
