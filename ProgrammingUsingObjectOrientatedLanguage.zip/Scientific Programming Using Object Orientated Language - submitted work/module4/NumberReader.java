package module4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NumberReader {
	
	private double minValue;
	private double maxValue;
	private double nValues;
	private double sumOfValues;
	private PrintWriter pw;
	
	// creating method which will take a URL address as the argument
	public static BufferedReader brURL (URL u) {
		InputStream is = null;
		try {
			is = u.openStream();
		} catch (IOException e) {
			System.out.println("Error: Please check that a correct URL address has been entered"+e);
			}
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		return b;
		}
	
	// creating a method which will read the URL file
	public static BufferedReader brFile (String fn) {
		BufferedReader r = null;
		try {
			r = new BufferedReader(new FileReader(fn));
		} catch (FileNotFoundException e) {
			System.out.println("Unfortunately the file was not found"+e);
		}
		return r;
	}

	// creating a method which will begin analysis on the URL file by initiating minVal, maxVal
	// no. of values and sum of Values and create a numbers.txt file
	public void analysisStart () {
		File outfile = new File("R:\\wts\\mywork\\numbers.txt");
		FileWriter fw = null;
		try {
			fw = new FileWriter(outfile);
		} catch (IOException e) {
			System.out.println("Unable to write to file"+e);
		}
		BufferedWriter b = new BufferedWriter(fw);
		pw = new PrintWriter(b);
		minValue = 10; maxValue = 0; nValues = 0; sumOfValues = 0;
	}
	
	// creating method which will analyse the data in the URL file ignoring blank line and 
	// comment lines. It will adjust minVal, maxVal,no. of Values and sum of Values accordingly
	// and print lines containing numbers to screen and to numbers.txt file
	public void analyseData(String s) {
		String st = s.trim();
		Scanner t = new Scanner(st);
		while (t.hasNextDouble()) {
			Double Value = t.nextDouble();
		String token = Double.toString(Value);
		if (Value < minValue) {
			minValue = Value;
		}
		if (Value > maxValue) {
			maxValue = Value;
		}
		nValues++; sumOfValues = sumOfValues + Value;
		System.out.println(""+token);
		pw.println(token);
		}
	}
	
	// creating method which will finish analysis by printing to screen the final minVal,
	// maxVal, no. of values and average value. It will also finish writing to numbers.txt file.
	public void analysisEnd () {
		double av = sumOfValues/nValues;
		System.out.println("Minimum Value = "+minValue+"\nMaximum Value = "+maxValue+
				"\nAverage = "+av+"\nNo. of values = "+nValues+"\n");
		pw.close();
	}
	
	public static void main(String[] args) {
		// testing methods using URL "http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/data1.txt"
		NumberReader nr1 = new NumberReader ();
		URL u1 = null;
		try {
			u1 = new URL ("http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/data1.txt");
			System.out.println("URL = "+u1);
		} catch (MalformedURLException e) {
			System.out.println("Please check that a valid URL address has been entered"+e);
		}
		BufferedReader br1 = brURL(u1);
		String line1 = "";
		// initialise the minValue etc 
		nr1.analysisStart(); 
		try {
			// read each line until last line reached
			while ((line1 = br1.readLine()) != null) { 
			// check if line is a comment etc 
				nr1.analyseData(line1); 
			}
		} catch (IOException e) {
			System.out.println("Unable to read file"+e);
		}
		// print min,max,average, no. of val
		nr1.analysisEnd();
		
		// testing method using URL "http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/data2.txt"
		NumberReader nr2 = new NumberReader ();
		URL u2 = null;
		try {
			u2 = new URL ("http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/data2.txt");
			System.out.println("URL = "+u2);
		} catch (MalformedURLException e) {
			System.out.println("Please check that a valid URL address has been entered"+e);
		}
		BufferedReader br2 = brURL(u2);
		String line2 = "";
		nr2.analysisStart(); 
		try {
			while ((line2 = br2.readLine()) != null) { 
				nr2.analyseData(line2); 
			}
		} catch (IOException e) {
			System.out.println("Unable to read file"+e);
		}
		nr2.analysisEnd();
	}

}
