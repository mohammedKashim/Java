package module6;

//creating a Exception subclass which will create a TheoryException
@SuppressWarnings("serial")
public class TheoryException extends Exception {

	public TheoryException() {}

	public TheoryException(String message) {
		super("TheoryException ERROR: "+message);
	}
	
}