package module6;

public interface DataOutput {
	
	// the DataOutput interface will have the 'store' method which will store a string
	// to the data output source and a 'close' method which will end the outputting data
	void store (String s);
	void close();

}
