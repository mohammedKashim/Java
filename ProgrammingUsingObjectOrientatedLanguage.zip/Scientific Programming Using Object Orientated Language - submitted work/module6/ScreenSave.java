package module6;

//the 'ScreenSave' class implements the DataOutput interface and will print to screen 
// a string 
public class ScreenSave
	implements DataOutput {

	// the 'store' method will begin printing a string to the screen
	public void store(String s) {
		System.out.println(s);
	}

	// the 'close' method will end printing to screen
	public void close() {}
	
}
