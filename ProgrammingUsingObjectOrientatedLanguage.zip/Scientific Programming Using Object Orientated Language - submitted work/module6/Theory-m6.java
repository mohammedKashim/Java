package module6;

public interface Theory {
	
	// the Theory interface will have the 'Y' method which will calculate the theoretical Y
	// value and a 'Name' method which will return a string of the name of the theory
	double Y(double x);
	String Name();
}
