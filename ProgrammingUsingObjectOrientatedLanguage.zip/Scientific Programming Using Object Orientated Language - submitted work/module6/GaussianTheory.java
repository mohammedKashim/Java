package module6;

//the 'GaussianTheory' class implements the Theory interface and will calculate the theoretical  
//Y value (according to Gaussian theory) to be used to determine the chi-squared value
public class GaussianTheory 
	implements Theory {
	
	double m;
	double s;
	
	// if no argument is passed in the constructor then default m and s values will be used
	public GaussianTheory() {
		m = 0; s = 1;
	}
	
	// the constructor throws an TheoryException if ss = 0 is passed as the argument
	public GaussianTheory (double mm, double ss) throws Exception {
		m = mm; s = ss;
		if (s == 0) {
			throw new TheoryException("cannot find Gaussain for s = 0");
		}
	}
	
	// creating a method which will calculate the theoretical Y value for Gaussain theory
	public double Y(double x) {
		double y = 1/(Math.sqrt(s*(2*Math.PI)))*Math.exp(-((x-m)*(x-m))/(2*s*s));
		return y;
	}

	// creating a method which will return the name of the theory along with the equation used
	public String Name() {
		String Name = "GaussianTheory : ";
		String m1 = Double.toString(m);
		String s1 = Double.toString(s);
		String Name1 = Name+"y = 1/("+s1+"*(2*PI)^0.5)*exp[(-(x-"+m1+")^2)/(2*("+s1+")^2)]";
		return Name1;
	}

}
