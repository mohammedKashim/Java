package module6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

// the 'FileSave' class implements the DataOutput interface and will create a file to which it
// will write a string to
public class FileSave 
	implements DataOutput {
	
	String fn;
	PrintWriter pw = null;
	
	// the 'FileSave' constructor will take the file name of the file to be created as 
	// an argument
	public FileSave (String filename) {
		fn = filename;
	}
	
	// the 'store' method will create a file and start writing a string to the file 
	public void store(String s) {
		File outfile = new File (fn);
		FileWriter fw = null;
		try {
			fw = new FileWriter(outfile);
		} catch (IOException e) {
			System.out.println("Unable to write to file"+e);
		}
		BufferedWriter b = new BufferedWriter(fw);
		pw = new PrintWriter(b);
		pw.println(s);
	}

	// the 'close' method will end writing to the file and save the file
	public void close() {
		pw.close();
	}

	
	
}


