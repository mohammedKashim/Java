package module6;

import java.lang.reflect.Array;

public class Matrix {
	
	double [][] theMatrixData;
	
	public Matrix(double[][] m) {
		theMatrixData = m;
	}
	
	// creating method which will return the no. of columns in the matrix passed in the argument
	public int nCols() {
		int nCols = Array.getLength(theMatrixData[0]);
		return nCols;
	}
	
	// creating method which will return the no. of rows in the matrix passed in the argument
	public int nRows() {
		int nRows = theMatrixData.length;
		return nRows;
	}
	
	// creating method which will check whether the matrix passed in the argument is
	// a square matrix
	public boolean isSquare() {
		if (this.nCols() == this.nRows()){
			return true;
		}
		else return false;
	}
	
	// creating method which will return the diagonal matrix of the matrix passed in the 
	// argument (will return error is the matrix is not square)
	public Matrix diagonal() throws Exception {
		if (this.isSquare() == false) {
			throw new Exception ("cannot return a diagonal matrix of a non-square matrix");
		}
		Matrix m = new Matrix(null);
		for (int i = 0; i < this.nCols(); i++){
			for (int j = 0; j < this.nRows(); j++) {
				if (i == j){
					double x = this.theMatrixData[i][j];
					double[][] dm = new double [this.nRows()][this.nCols()];
					dm[i][j] = x;
					m = new Matrix (dm);}}}
		return m;
	}
	
	// creating method which will return the sum of the two matrices passed in the argument
	public static Matrix add(Matrix m1, Matrix m2) throws Exception {
		if (m1.nRows() != m2.nRows() &&  m1.nCols() != m2.nCols()){
			throw new Exception ("cannot calculate sum of two matrices of unequal rank");}
		Matrix m = new Matrix(null);
		for (int x1 = 0; x1 < m1.nRows(); x1++) {
			for (int y1 =0; y1 < m1.nCols(); y1++){
				for (int x2 = 0; x2 < m2.nRows(); x2++) {
					for (int y2 =0; y2 < m2.nCols(); y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = m1.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							double nn = n1 + n2;
							double[][] dm = new double [m1.nRows()][m1.nCols()];
							dm[x1][y1] = nn;
							m = new Matrix (dm);}}}}}
		return m;
	}
	
	// creating non-static version of 'add' method
	public Matrix add(Matrix m2) throws Exception {
		return add (this, m2);
	}
	
	// creating method which will check whether the two matrices passed in the argument are equal
	public static boolean equals (Matrix m1, Matrix m2) {
		for (int x1 = 0; x1 < m1.nRows(); x1++) {
			for (int y1 =0; y1 < m1.nCols(); y1++){
				for (int x2 = 0; x2 < m2.nRows(); x2++) {
					for (int y2 =0; y2 < m2.nCols(); y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = m1.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							if (n1 == n2){
								return true;
							}
							else return false;}}}}}
		return false;
	}
	
	// creating non-static version of 'equals' method
	public boolean equals(Matrix m2) {
		return equals (this, m2);
	}
	
	// creating method which will set how the 'Matrix' object should be printed to screen
	public String toString () {
		System.out.print("(");
		for (int i = 0; i < this.nCols(); i++){
			if (i==1){System.out.println("");}
			System.out.print("{");
			for (int j = 0; j < this.nRows(); j++) {
				double x = this.theMatrixData[i][j];
				System.out.print(""+x+"");
				if (j == this.nRows()-1) {System.out.print("}");} 
				else {System.out.print(",");}}}
		return ")";
	}
	
	// creating a method which will the return the transpose of the matrix passed in
	// the argument
	public static Matrix transpose(Matrix m) {
		double[][] dm = new double [m.nCols()][m.nRows()];
		for (int x1 = 0; x1 < m.nRows(); x1++) {
			for (int y1 =0; y1 < m.nCols(); y1++){
				double n = m.theMatrixData[x1][y1];
				dm[y1][x1] = n;
			}	
		}
		m = new Matrix (dm);
		return m;
	}
	
	// creating non-static version of 'transpose' method
	public Matrix transpose() {
		return transpose (this);
	}

	public static void main(String[] args) {
		// check whether the 'transpose' method added in module 6 works
		double[][] m1 = {{0,1},{2,3}};
		Matrix M1 = new Matrix(m1);
		System.out.println("M1 = ");
		System.out.println(""+M1); 
		System.out.println("transpose of M1 = ");
		System.out.println(M1.transpose());
	}
}
