package module6;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import module5.DataPoint;

public class DataAnalysis {
	
	// using Map interface instead of instantiating a HashMap
	public static Map<Integer, DataPoint> map;
	
	// creating method which will read the given URL and insert the required values into a 
	// HashMap (which must first be instantiated)
	public void readURL(String url) throws Exception {
		URL u = new URL(url);
		InputStream is = u.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		Scanner t = new Scanner (b);
		int n =0;
		// instantiating the Map as a HashMap and adding values
		map = new HashMap<Integer, DataPoint>();
		while (t.hasNext()) {
			Double Value1 = t.nextDouble();
			Double Value2 = t.nextDouble();
			Double Value3 = t.nextDouble();
			Integer Key = t.nextInt();
			map.put(Key,new DataPoint(Value1,Value2,Value3));
			n++;
		}
		System.out.println("total no. of datapoints in file = "+n);
		System.out.println("no. of datapoints in map = "+map.size());
	}
	
	// creating a method which will take the values from the HashMap and convert it to a list
	public static List<DataPoint> dataPoints(){
		List<DataPoint>al = new ArrayList<DataPoint>();
		al.addAll(map.values());
		return al;
	}
	
	// creating a method which will calculate the goodness of fit of the data to a theoretical
	// fit passed in the argument (using chi-squared)
	public static double goodnessOfFit(Theory theory, List<DataPoint> al) {
		double Xsqr = 0;
		for (DataPoint dp : al) {
			double Xsqr1 = Math.pow(dp.get_y()-theory.Y(dp.get_x()),2)/Math.pow(dp.get_ey(),2);
			Xsqr=Xsqr+Xsqr1;
		}
		return Xsqr;
	}
	
	// creating a method which will write the string passed in the argument to the data output 
	// source passed in the argument 
	public void output(String s, DataOutput DO) {DO.store(s);}
	
	// creating a method which will end the data output passed in the argument
	public void close(DataOutput DO) {DO.close();}

	public static void main(String[] args) throws Exception {
		DataAnalysis a = new DataAnalysis();
		// instantiating the Gaussian and Quadratic theory
		GaussianTheory gt = new GaussianTheory();
		QuadraticTheory qt = new QuadraticTheory(1,0,0);
		System.out.println(gt.Name());
		System.out.println(qt.Name());
		String sg = null; String dg = null;
		// begin reading file and calculating the goodness of fit to each theory
		try {
			a.readURL("http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/exercise5.data"); 
			System.out.println("no. of datapoints = " + DataAnalysis.dataPoints().size());
			double goodnessOfFit1 = DataAnalysis.goodnessOfFit(gt, dataPoints());
			double goodnessOfFit2 = DataAnalysis.goodnessOfFit(qt, dataPoints());
			// converting the goodness of fit values to string
			double g = goodnessOfFit1;
			sg = Double.toString(g);
			double d = goodnessOfFit2;
			dg = Double.toString(d);
		} catch (Exception e) {}
		// instantiating the data output methods
		DataOutput FileSave = new FileSave("R:\\wts\\mywork\\Xsqr.txt"); 
		DataOutput ScreenSave = new ScreenSave();
		// Outputting data to specified sources 
		a.output("Gaussian Theory, Xsqr = "+sg,FileSave);
		a.output("Gaussian Theory, Xsqr = "+sg,ScreenSave);
		a.output("Quadratic Theory, Xsqr = "+dg,FileSave);
		a.output("Quadratic Theory, Xsqr = "+dg,ScreenSave);
		a.close(ScreenSave);
		a.close(FileSave);

	}
}
