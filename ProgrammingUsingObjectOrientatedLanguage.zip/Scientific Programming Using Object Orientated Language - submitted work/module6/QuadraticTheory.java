package module6;

//the 'QuadraticTheory' class implements the Theory interface and will calculate the theoretical  
//Y value (according to Quadratic theory) to be used to determine the chi-squared value
public class QuadraticTheory 
	implements Theory {
	
	double aa;
	double bb;
	double cc;
	
	public QuadraticTheory (double a, double b, double c) {
		aa = a; bb = b; cc = c;
	}
	
	// creating a method which will calculate the theoretical Y value for Quadratic theory
	public double Y(double x) {
		double y = (aa*x)*(aa*x)+bb*x+cc;
		return y;
	}

	// creating a method which will return the name of the theory along with the equation used
	public String Name() {
		String Name = "QuadraticTheory : ";
		String a = Double.toString(aa);
		String b = Double.toString(bb);
		String c = Double.toString(cc);
		String Name1 = Name+"y = "+a+"x^2 + "+b+"x + "+c;
		return Name1;
	}

}
