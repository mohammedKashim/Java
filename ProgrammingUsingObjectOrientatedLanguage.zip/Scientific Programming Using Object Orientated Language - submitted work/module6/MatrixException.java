package module6;

// creating a Exception subclass which will create a MatrixException
@SuppressWarnings("serial")
public class MatrixException extends Exception {

	public MatrixException() {}

	public MatrixException(String message) {
		super("MatrixException ERROR: "+message);
	}

}