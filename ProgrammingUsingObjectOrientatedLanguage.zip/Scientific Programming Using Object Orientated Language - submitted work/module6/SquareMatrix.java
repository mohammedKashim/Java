package module6;

import module6.Matrix;

public class SquareMatrix extends Matrix {
	
	double [][] theMatrixData;

	// the SquareMatrix class extends the Matrix class and will throw a MatrixException
	// if the matrix passed is not a square matrix
	public SquareMatrix(double[][] m) throws Exception {
		super(m);
		Matrix a = new Matrix(m);
		if (a.isSquare() == false) {
			throw new MatrixException ("the matrix is not a square matrix");
		}
	}
	
	// creating a method which will the return the transpose of the matrix passed in
	// the argument
	public static Matrix transpose(Matrix m) {
		double[][] dm = new double [m.nCols()][m.nRows()];
		for (int x1 = 0; x1 < m.nRows(); x1++) {
			for (int y1 =0; y1 < m.nCols(); y1++){
				double n = m.theMatrixData[x1][y1];
				dm[y1][x1] = n;
			}	
		}
		m = new Matrix (dm);
		return m;
	}
	
	// creating non-static version of 'transpose' method
	public Matrix transpose() {
		return transpose (this);
	}
	
	// creating a method which will check whether the square matrix passed in the argument
	// is symmetric
	public static boolean isSymmetric(SquareMatrix m) {
		Matrix m1 = m;
		for (int x1 = 0; x1 < m1.nRows(); x1++) {
			for (int y1 =0; y1 < m1.nCols(); y1++){
				if (m1.theMatrixData[x1][y1] != m1.theMatrixData[y1][x1]) {
					return false;}}}
		return true;
	}

	// creating non-static version of 'isSymmetric' method
	public boolean isSymmetric() {
		return isSymmetric(this);
	}
	
	// creating a method which will return the trace of the square matrix passed in the argument
	public static double trace(SquareMatrix sq) {
		Matrix m = sq;
		double x = 0;
		for (int i = 0; i < sq.nRows(); i++){
			for (int j = 0; j < sq.nCols(); j++) {
				if (i == j){
					double x1 = m.theMatrixData [i][j];
					x = x1;}}}
		return x;
	}
	
	// creating non-static version of 'trace' method
	public double trace() {
		return trace(this);
	}
	
	public static void main(String[] args) {
		double[][] m1 = {{0,1},{2,3}};
		double[][] m2 = {{0,1,3},{2,3,1}};
		SquareMatrix M1 = null;
		// check whether matrix M1 and M2 are square matrices (M2 should give error)
		try {
			M1 = new SquareMatrix(m1);
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			@SuppressWarnings("unused")
			SquareMatrix M2 = new SquareMatrix(m2);
		} catch (Exception e) {
			System.out.println(e);
		}
		// check whether methods in this class work
		System.out.println("M1 = ");
		System.out.println(""+M1); 
		System.out.println("transpose of M1 = ");
		System.out.println(""+M1.transpose());
		System.out.println("Is M1 Symmetric? "+M1.isSymmetric());
		System.out.println("trace of M1 = "+M1.trace());
		

	}

}
