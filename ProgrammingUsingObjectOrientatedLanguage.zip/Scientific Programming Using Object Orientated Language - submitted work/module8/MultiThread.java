package module8;

public class MultiThread {

	public static void main(String[] args) {
		// creating the four thread objects and start them using the start() method
		KeyBoardThread kbt = new KeyBoardThread();
		MemoryThread mt = new MemoryThread();
		ClockThread ct = new ClockThread(100);
		DataReadThread drt = new DataReadThread("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/bpm.txt");
		kbt.start();
		mt.start();
		ct.start();
		drt.start();
		double a = 0;
		double pt1 = System.currentTimeMillis();
		// adding a while loop which will print the number of active threads every second.
		// this while loop will terminate after 1 minute
		while (a < 60000) {
			int numThreads = Thread.currentThread().getThreadGroup().activeCount();
			System.out.println("no. of active threads  = "+numThreads);
			double pt2 = System.currentTimeMillis();
			a = pt2-pt1;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {}
		}
		kbt.stop();
		mt.stop();
		ct.stop();
		drt.stop();
	}

}
