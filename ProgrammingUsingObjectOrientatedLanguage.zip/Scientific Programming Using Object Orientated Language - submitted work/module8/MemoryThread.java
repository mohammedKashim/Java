package module8;

//This class implements the interface Runnable so that it can be run as a thread. 
//The MemoryThread will monitor the memory usage on the system. 
public class MemoryThread implements Runnable {

	private Thread t;

	// creating method which will start the thread
	public void start() {
		if (t == null) {
			t = new Thread(this,"MemoryThread");
			t.start();
		}
	}
	
	// creating the run method which will print amount of memory being used 
	// to the screen every 5 seconds.
	public void run() {
		while (!t.isInterrupted()) {
			if (Thread.currentThread().isInterrupted()) return; {
				Runtime r = Runtime.getRuntime(); 
				long memoryUsed = r.totalMemory() - r.freeMemory();
				System.out.println("\nMemory being used: "+memoryUsed);
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					System.out.println("Thread has been interrupted");
					break;
				}
			}
		}
	}
	
	// creating method which will end the thread
	public void stop() {
		t.interrupt();
		System.out.println("MemoryThread stopped");
	}

}
