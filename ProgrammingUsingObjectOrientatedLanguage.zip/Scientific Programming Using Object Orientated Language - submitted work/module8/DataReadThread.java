package module8;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

//This class implements the interface Runnable so that it can be run as a thread. 
//The DataReadThread will print to the screen the contents of a URL. 
public class DataReadThread implements Runnable {
	
	public String url;
	private Thread t;
	
	// the constructor will take the URL as the argument
	public DataReadThread (String URL) {
		url = URL;
	}
	
	// creating method which will start the thread
	public void start() {
		if (t == null) {
			t = new Thread(this,"DataReadThread");
			t.start();
		}
	}
	
	// creating run() method which will read the URL and print the contents to the screen one line 
	// at a time. The run() method will end when the URL has been read.  
	public void run() {
		if (Thread.currentThread().isInterrupted()) return; {
			URL u = null;
			try {
				u = new URL(url);
			} catch (MalformedURLException e) {
				System.out.println("URL not found");
			}
			InputStreamReader isr = null;
			try {
				isr = new InputStreamReader(u.openStream());
			} catch (IOException e) {
				System.out.println("Unable to read URL");
			}
			BufferedReader b = new BufferedReader(isr);
			String line = "";
			try {
				while ((line = b.readLine()) != null) { 
					System.out.println(""+line);
				}
			} catch (IOException e) {
				System.out.println("Unable to read line"+e);
			}
			stop();
		}
	}
	
	// creating method which will end the thread
	public void stop() {
		t.interrupt();
		System.out.println("DataReadThread stopped");
	}

}
