package module8;

import java.util.Date;

// This class implements the interface Runnable so that it can be run as a thread. 
// The ClockReadThread will will monitor the time. 
public class ClockThread implements Runnable {
	
	public int ss;
	private Thread t;
	
	// the constructor will take the time (in seconds)the thread runs for as the argument 
	public ClockThread (int s) {
		ss = s;
	}

	// creating method which will start the thread
	public void start() {
		if (t == null) {
			t = new Thread(this,"ClockThread");
			t.start();
		}
	}
	
	// creating run()method which will print the current time to the screen every five seconds
	// until the elapsed time set has been reached
	public void run() {
		while (!t.isInterrupted()) {
			if (Thread.currentThread().isInterrupted()) return; {
				double ct1 = System.currentTimeMillis();
				Date timeNow = new Date(); 
				System.out.println(timeNow.toString()); 
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					System.out.println("Thread has been interrupted");
				}
				double ct2 = System.currentTimeMillis();
				double s = ct1 - ct2;
				if (s == ss) {
					stop();
				}
				break;
			}
		}
	}
	
	// creating method which will end the thread
	public void stop() {
		t.interrupt();
		System.out.println("ClockThread stopped");
	}
	
	
}
