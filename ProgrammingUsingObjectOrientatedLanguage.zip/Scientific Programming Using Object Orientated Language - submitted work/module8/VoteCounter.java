package module8;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class VoteCounter extends JFrame {

	static int nlClick = 0;
	static int nrClick = 0;
	static int totClicks = 0;
	static double percYes = 0;
	static double percNo = 0;

	
	// creating method that paint the GUI and increase no. of left clicks by 1 every time
	// the left mouse button is clicked and increase n0. of right clicks by 1 every time
	// the right button is clicked by one. It will also calculate total no. of clicks.
	public VoteCounter() {
		super();
		MouseListener m = new MouseListener() {
			public void mouseClicked(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e)== true ) {nlClick++;}
				if (SwingUtilities.isRightMouseButton(e)== true ) {nrClick++;}
				totClicks = nlClick + nrClick;
				if (totClicks != 0 ) {
					percYes = (double)Math.round(100*((double) nlClick)/totClicks);
					percNo = (double)Math.round(100*((double) nrClick)/totClicks);
				}
				repaint();
			}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		};
		addMouseListener(m);
	}
	
	// creating method which determines the size of the rectangle which will represent 
	// the percentage of votes
	public void createAndDisplayGui(Graphics g, int x, int y, int w, int h) {     
		if(w < 0)         
			x-=Math.abs(w);     
		if(h < 0)         
			y-=Math.abs(h);    
		g.fillRect(x, y,Math.abs(w), Math.abs(h));  
	}

	// creating "paint" method which will create the two rectangles for percentage of
	// yes and no votes and also add labels
	public void paint(Graphics g) {
		super.paint(g);
		if (totClicks > 0) {
			double yH = -300*nlClick/totClicks;
			double nH = -300*nrClick/totClicks;
			g.setColor(Color.GREEN);
			createAndDisplayGui(g,150, 500, 100, (int) yH);
			g.setColor(Color.RED);
			createAndDisplayGui(g,250, 500, 100, (int) nH);
			g.setColor(Color.BLACK);
			Font title = new Font("TimesRoman",Font.BOLD,30);
			g.setFont(title);
			g.drawString("Number of votes cast = "+totClicks,100,100);
			g.setColor(Color.BLACK);
			Font f = new Font("TimesRoman",Font.BOLD,20);
			g.setFont(f);
			g.drawString("YES:"+percYes+"%",150,(int) (500+yH));
			g.drawString("NO:"+percNo+"%",250,(int) (500+nH));
		}
	}

	public static void main(String args[]) {
		// creating new frame which will instantiate the VoteCounter() methods
		JFrame frame = new VoteCounter();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		// setting size of initial frame
		frame.setSize(500, 500);
		frame.setVisible(true);
		
	
	}
}
