package module8;

import java.io.*;

// This class implements the interface Runnable so that it can be run as a thread. 
// The KeyBoardThread will wait for data to be entered from the keyboard before beginning. 
public class KeyBoardThread implements Runnable {

	private Thread t;
	
	// creating method which will start the thread
	public void start() {
		if (t == null) {
			t = new Thread(this,"KeyBoardThread");
			t.start();
		}
	}
	
	// creating the run method which will run the thread. It will wait for an input to be entered 
	// from the keyboard and when input is received it will be printed to the screen
	public void run() {
		while (!t.isInterrupted()) {
			if (Thread.currentThread().isInterrupted()) return; {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
				String s = null;
				try {
					s = br.readLine();
					System.out.println("You wrote: "+s);
				} catch (IOException e) {
					System.out.println("Error in reading line");
				}
				if (s.contains("EXIT")) {
					stop();
					break;
				}
			}
		}
	}
	
	// creating method which will end the thread
	public void stop() {
		t.interrupt();
		System.out.println("KeyboardThread stopped");
	}

}
