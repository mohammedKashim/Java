package exam1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;


public class ParticleBeam {

	// creating method which will take a URL address as the argument
	public static BufferedReader brURL (URL u) {
		InputStream is = null;
		try {
			is = u.openStream();
		} catch (IOException e) {
			System.out.println("Error: Please check that a correct URL address has been entered"+e);
		}
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		return b;
	}

	// creating a method which will read the URL file
	public static BufferedReader brFile (String fn) {
		BufferedReader r = null;
		try {
			r = new BufferedReader(new FileReader(fn));
		} catch (FileNotFoundException e) {
			System.out.println("Unfortunately the file was not found"+e);
		}
		return r;
	}

	// creating a method which will analyse the data in the file
	public void analyseData (String s) {
		String st = s.trim();
		Scanner t = new Scanner (st);
		double x = 0; double y = 0; int z = 0; int num = 0; double rsqr = 0;
		double maxr = 0;
		// creating a while loop which will loop over all the data in the file and will 
		// determine the x, y, and z position
		while (t.hasNextDouble()) {
			double x1 = t.nextDouble();
			double y1 = t.nextDouble();
			int z1 = t.nextInt();
			// determine the separation between the corresponding z values 
			// (separation distance of BPMs)
			int separation = z1-z;
			z = z1; 
			// determine no. of particles measured
			num++;
			// determine the mean x and y positions and print to screen
			x = x+x1;
			y = x+y1;
			double avx = x/num; System.out.println("mean x position = "+avx);
			double avy = y/num; System.out.println("mean y position = "+avy);
			// determine the radial distance for each particle
			double risqr = (x1-avx)*(x1-avx)+(y1-avy)*(y1-avy);
			double ri = Math.sqrt(risqr);
			// determine the maximum radius measured
			if (ri > maxr){
				maxr = ri;
			} 
			// calculate the sum of all radial distances
			rsqr = rsqr+risqr;
		}
		// calculate the rms radius
		double rms = Math.sqrt(rsqr/num);
		System.out.println("rms = "+rms);
		System.out.println("maximum radius = "+maxr);
	}

	public static void main(String[] args) {
		// running programme using URL "http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/bpm.txt"
		ParticleBeam a = new ParticleBeam();
		URL u = null;
		try {
			u = new URL("http://www.hep.ucl.ac.uk/undergrad/3459/exam-data/bpm.txt");
		} catch (Exception e) {
			System.out.println("Error in URL");
		}
		BufferedReader br = brURL(u);
		String line = "";
		try {
			while ((line = br.readLine()) != null) {
				a.analyseData(line);
			}
		} catch (IOException e) {
			System.out.println("Error in reading file");
		}
	}

}
