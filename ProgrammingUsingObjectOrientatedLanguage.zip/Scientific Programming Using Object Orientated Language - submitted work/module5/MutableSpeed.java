package module5;

import module3.Alphabet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class MutableSpeed {
	
	private String filename1;

	public Object writeFile (String filename) {
		filename1 = filename;
		File outfile = new File(filename);
		FileWriter fw = null;
		try {
			fw = new FileWriter(outfile);
		} catch (IOException e) {
			System.out.println("Unable to write to file"+e);
		}
		BufferedWriter b = new BufferedWriter(fw);
		PrintWriter pw = new PrintWriter(b);
		Alphabet a = new Alphabet();
		char[] lines = new char[100];
		for (int y =0; y < 10000; y++) {
			for (int x = 0; x < lines.length; x++) {
				lines [x] = a.randomChar();	
			}
			char[] token = lines;
			pw.println(token);
		}
		pw.close();
		return outfile;
	}
	
	public void readFileString() {
		BufferedReader r = null;
		try {
			FileReader fr = new FileReader(filename1);
			r = new BufferedReader (fr);
		} catch (FileNotFoundException e) {
			System.out.println("Unfortunately the file was not found"+e);
		}
		String line = "";
		try {
			while ((line = r.readLine()) != null) { 
				System.out.println(""+line);
			}
		} catch (IOException e) {
			System.out.println("Unable to read file"+e);
		}
	}
	
	public void readFileStringBuilder() {
		BufferedReader r = null;
		try {
			FileReader fr = new FileReader(filename1);
			r = new BufferedReader (fr);
		} catch (FileNotFoundException e) {
			System.out.println("Unfortunately the file was not found"+e);
		}
		String line = "";
		StringBuilder z = null;
		try {
			while ((line = r.readLine()) != null) { 
				z = new StringBuilder(line);
				String file = z.toString();
				System.out.println(""+file);
			}
		} catch (IOException e) {
			System.out.println("Unable to read file"+e);
		}
	}

	public static void main(String[] args) {
		MutableSpeed m = new MutableSpeed(); 
		m.writeFile("R:\\wts\\mywork\\file.txt");
		// Determine the present time
		double ptime1 = System.currentTimeMillis(); 
		m.readFileString();
		// determine time taken for method to run
		double t1 = (System.currentTimeMillis()- ptime1); 
		// Determine current time
		double ptime2 = System.currentTimeMillis();
		m.readFileStringBuilder();
		// Determine time taken for method to run
		double t2 = System.currentTimeMillis()- ptime2; 
		// calculate ratio
		double Ratio = (t1/t2);
		System.out.println("ratio of time taken = "+Ratio);

	}

}
