package module5;

public class Theory {
	
	public double n;
	
	public Theory (double nn){
		nn = n;
	}
	
	public double Y(double x) {
		double y = Math.pow(x,n);
		return y;
	}
	

}


