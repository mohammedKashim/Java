package module5;

public class DataPoint {

	public double x;
	public double y;
	public double ey;
	
	public DataPoint (double xx, double yy, double eyy){
		x = xx; y = yy; ey = eyy;
		System.out.println("x = "+xx);
		System.out.println("y = "+yy);
		System.out.println("ey = "+eyy);
	}
	
	public String toString() {
		return "x = "+x+" y = "+y+" ey = "+ey;
		
	}

}
