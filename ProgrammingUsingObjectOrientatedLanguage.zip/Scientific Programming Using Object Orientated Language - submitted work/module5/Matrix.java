package module5;

import java.lang.reflect.Array;

public class Matrix {
	
	double [][] theMatrixData;
		
	public Matrix(double[][] m) {
		theMatrixData = m;
	}
	
	public int nCols() {
		int nCols = Array.getLength(theMatrixData[0]);
		return nCols;
	}
	
	public int nRows() {
		int nRows = theMatrixData.length;
		return nRows;
	}
	
	public boolean isSquare() {
		if (this.nCols() == this.nRows()){
			return true;
		}
		else
		return false;
	}
	
	public Matrix diagonal() throws Exception {
		if (this.isSquare() == false) {
			throw new Exception ("cannot return a diagonal matrix of a non-square matrix");
		}
		Matrix m = new Matrix(null);
		for (int i = 0; i < this.nCols(); i++){
			for (int j = 0; j < this.nRows(); j++) {
				if (i == j){
					double x = this.theMatrixData[i][j];
					double[][] dm = new double [this.nRows()][this.nCols()];
					dm[i][j] = x;
					m = new Matrix (dm);}}}
		return m;
	}
	
	public Matrix add(Matrix m2) throws Exception {
		double c1 = this.nCols(); double r1 = this.nRows();
		double c2 = m2.nCols(); double r2 = m2.nRows();
		if (c1 != c2 &&  r1 != r2){
			throw new Exception ("cannot calculate sum of two matrices of unequal rank");}
		Matrix m = new Matrix(null);
		for (int x1 = 0; x1 < r1; x1++) {
			for (int y1 =0; y1 < c1; y1++){
				for (int x2 = 0; x2 < r2; x2++) {
					for (int y2 =0; y2 < c2; y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = this.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							double nn = n1 + n2;
							double[][] dm = new double [this.nRows()][this.nCols()];
							dm[x1][y1] = nn;
							m = new Matrix (dm);}}}}}
		return m;
	}
	
	public static Matrix add(Matrix m1, Matrix m2) throws Exception {
		if (m1.nRows() != m2.nRows() &&  m1.nCols() != m2.nCols()){
			throw new Exception ("cannot calculate sum of two matrices of unequal rank");}
		Matrix m = new Matrix(null);
		for (int x1 = 0; x1 < m1.nRows(); x1++) {
			for (int y1 =0; y1 < m1.nCols(); y1++){
				for (int x2 = 0; x2 < m2.nRows(); x2++) {
					for (int y2 =0; y2 < m2.nCols(); y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = m1.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							double nn = n1 + n2;
							double[][] dm = new double [m1.nRows()][m1.nCols()];
							dm[x1][y1] = nn;
							m = new Matrix (dm);}}}}}
		return m;
	}
	
	public boolean equals(Matrix m2) {
		for (int x1 = 0; x1 < this.nRows(); x1++) {
			for (int y1 =0; y1 < this.nCols(); y1++){
				for (int x2 = 0; x2 < m2.nRows(); x2++) {
					for (int y2 =0; y2 < m2.nCols(); y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = this.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							if (n1 == n2){
								return true;
							}
							else return false;}}}}}
		return false;
	}
	
	public static boolean equals (Matrix m1, Matrix m2) {
		for (int x1 = 0; x1 < m1.nRows(); x1++) {
			for (int y1 =0; y1 < m1.nCols(); y1++){
				for (int x2 = 0; x2 < m2.nRows(); x2++) {
					for (int y2 =0; y2 < m2.nCols(); y2++){
						if (x1 == x2 && y1 ==y2) {
							double n1 = m1.theMatrixData[x1][y1];
							double n2 = m2.theMatrixData[x2][y2];
							if (n1 == n2){
								return true;
							}
							else return false;}}}}}
		return false;
	}
	
	public String toString () {
		System.out.print("(");
		for (int i = 0; i < this.nCols(); i++){
			if (i==1){System.out.println("");}
			System.out.print("{");
			for (int j = 0; j < this.nRows(); j++) {
				double x = this.theMatrixData[i][j];
				System.out.print(""+x+"");
				if (j == this.nRows()-1) {System.out.print("}");} 
				else {System.out.print(",");}}}
		return ")";
	}
	
	public static void main(String[] args) {
		double[][] m1 = {{0,1},{2,3}};
		double[][] m2 = {{0,1},{2,3}};
		Matrix M1 = new Matrix(m1);
		Matrix M2 = new Matrix(m2);
		System.out.println("M1 = ");
		System.out.println(""+M1); 
		System.out.println("M2 =  ");
		System.out.println(""+M2);
		double x = M1.nCols();
		double y = M1.nRows();
		System.out.println("no. of columns = "+x);
		System.out.println("no. of rows = "+y);
		System.out.println("Is M1 a square matrix? "+M1.isSquare());
		try {
			Matrix f = M1.diagonal();
			System.out.println("Diagonalise M1 = ");
			System.out.println(""+f);
			} catch (Exception e) {}
		try {
			Matrix a = M1.add(M2);
			System.out.println("add M1 & M2 = ");
			System.out.println(""+a);
		} catch (Exception e) {}
		System.out.println("Are M1 & M2 equal? "+M1.equals(M2));
		
	}
}
