package module5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;


public class DataAnalysis {
	
	HashMap<Integer,DataPoint> id = null;
	static ArrayList<DataPoint> al = null;

	public void readURL(String url) throws Exception {
		URL u = new URL(url);
		InputStream is = u.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader b = new BufferedReader(isr);
		Scanner t = new Scanner (b);
		HashMap <Integer, DataPoint> id = new HashMap <Integer, DataPoint>();
		while (t.hasNext()) {
			Double Value1 = t.nextDouble();
			Double Value2 = t.nextDouble();
			Double Value3 = t.nextDouble();
			Integer Key = t.nextInt();
			id.put(Key,new DataPoint(Value1,Value2,Value3));
		}
	}
	
	public Object dataPoints(){
		ArrayList<DataPoint> al = new ArrayList<DataPoint>(id.values());
		System.out.println(""+al);
		return al;
	}

	public static Double goodnessOfFit(Theory, DataPoint) {
		double a = 0;
		for(int i=0; i < al.size(); i++) {   
			double Xsqr = ((al.get(Value2)-Theory)^2)/(al.get(Value3))^2;
		}   
		return Xsqr;
	}
	
	public static void main(String[] args) throws Exception {
		DataAnalysis a = new DataAnalysis();
		a.readURL("http://www.hep.ucl.ac.uk/~rjn/teaching/phas3459/exercise5.data");
		a.dataPoints();
		double Xsqr = DataAnalysis.goodnessOfFit();
		System.out.println("Xsqr = "+Xsqr);

	}

}
